# Kasandra – offline probuzení asistenta slovem „kasandro“

Android aplikace, která i při zhasnutém displeji poslouchá mikrofon a reaguje na slovo
**„kasandro“** vyslovené *tvým* hlasem. Vše běží v telefonu – žádné cloudové služby,
žádný internet, nic se nikam neposílá.

Od verze 0.2 po zachycení slova řekne **„Ano?“**, nahraje tvůj příkaz, offline ho přepíše
na text (Vosk, český model přibalený v APK) a pošle do backendu **Kasandry** v domácí síti
(`POST /chat`); odpověď přečte nahlas. Když Kasandra odpoví otázkou („Jaký úkol?“), apka
poslouchá dál a tvé upřesnění přilepí k původnímu příkazu. Adresa backendu se nastavuje
v aplikaci (sekce „Spojení s Kasandrou“); telefon musí být na stejné Wi-Fi jako počítač
s Kasandrou. Do internetu se neposílá nic – jediná síťová komunikace je text příkazu
do tvého vlastního backendu. Alternativně jde přepnout na pouhou testovací hlášku.

## Jak to funguje (stejný princip jako tvoje PC verze `voice_control.py`)

1. Každých 30 ms se spočítá jen hlasitost (RMS) – prakticky nulová zátěž procesoru.
2. Když hlasitost přeskočí adaptivní šumový práh, začne se sbírat úsek řeči, dokud
   nenastane 0,5 s ticha (max 2,5 s).
3. Úsek se ořízne, spočítají se MFCC a **DTW vzdálenost** k tvým uloženým vzorkům
   slova „kasandro“. Práh se dopočítá z rozptylu tvých vzorků (+ nastavitelná tolerance).
4. Navíc se porovná **výška hlasu (F0)** s tvými vzorky – odfiltruje výrazně jiné hlasy.
5. Shoda → vibrace + „Ano?“ → dialog s Kasandrou (viz výše), případně jen testovací hláška.

Přepis příkazů dělá **Vosk** s modelem `vosk-model-small-cs-0.4-rhasspy` (stejný, jaký
používá PC verze) – model do APK přibalí build na GitHubu, za běhu je vše v telefonu.

Protože se porovnává s *tvými* nahrávkami, nepotřebuje slovo „kasandro“ ve slovníku
žádného rozpoznávače a reaguje především na tvůj hlas. Není to ale biometrie – podobný
hlas se stejnou intonací může projít. Přísnost si doladíš dvěma posuvníky podle záznamu.

## Spotřeba

- Mikrofon musí běžet trvale (to je jediná nevyhnutelná zátěž – typicky jednotky % baterie
  za den, podle telefonu).
- Rozpoznávání se počítá **jen** na úsecích řeči, jedno vyhodnocení trvá ~2–5 ms.
- Wake lock je ve výchozím stavu **vypnutý** (audio systém drží procesor sám). Zapni ho
  jen pokud by Kasandra při zhasnutém displeji přestala reagovat.
- Skutečně nulovou spotřebu (hotword v DSP čipu) mají jen systémové aplikace výrobce –
  to třetí strana na Androidu použít nemůže.

## Sestavení (Android Studio – jednorázově cca 15 minut)

1. Nainstaluj **Android Studio** (https://developer.android.com/studio), při prvním
   spuštění nech stáhnout výchozí SDK.
2. *File → Open…* → vyber složku `kasandra-android` (tu s `settings.gradle`).
3. Počkej na „Gradle sync“ (poprvé stáhne knihovny, pár minut).
4. V telefonu zapni *Možnosti pro vývojáře → Ladění USB*, připoj ho kabelem
   (nebo *Bezdrátové ladění*).
5. Klikni na zelené **Run ▶**. Aplikace se nainstaluje a spustí.

Hotové APK (pro instalaci na další telefony) najdeš po *Build → Build APK(s)* v
`app/build/outputs/apk/debug/app-debug.apk`.

## První spuštění v telefonu

1. Povol mikrofon a oznámení.
2. **Nahrát 5 vzorků** – po každé výzvě řekni „kasandro“ a udělej pauzu. Nahraj klidně
   i další („Přidat 1 vzorek“) z větší dálky, tišeji, rychleji – čím pestřejší, tím lépe.
3. **Spustit naslouchání**, zhasni displej a řekni „kasandro“.
4. Sleduj **Záznam**: každý úsek řeči ukáže *vzdálenost / práh* a *výšku hlasu*.
   - Přeslýchá tě → zvyš *Toleranci shody* nebo nahraj další vzorky.
   - Spouští se na cizí řeč → sniž toleranci, případně zúž *odchylku výšky hlasu*.
5. Klikni na **Vyjmout z optimalizace baterie**, aby systém službu nezabíjel.
   U Xiaomi/Huawei/Samsung ještě v nastavení baterie povol „bez omezení“ / autostart.

## Známá omezení

- Po restartu telefonu nelze na novém Androidu spustit mikrofon z pozadí – Kasandra
  jen ukáže oznámení, jedním ťuknutím se poslech obnoví.
- Slovo je potřeba říct *samostatně* (s krátkou pauzou před a po), ne uprostřed věty –
  úsek se porovnává celý.
- „Spustit výchozího asistenta“ je experimentální: Android zakazuje spouštět aplikace
  z pozadí, potřebuje povolení *Zobrazení přes jiné aplikace* a i tak záleží na výrobci.
  Až se rozhodneš, jakého asistenta a jak volat (např. přepis příkazu Voskem s modelem
  `model-cs`, který už máš, a odeslání do vlastní aplikace), doplní se to do
  `ListenService.onWake()`.

## Struktura

```
app/src/main/java/cz/kamil/kasandra/
  Dsp.kt            – RMS, ořez ticha, FFT, MFCC, odhad výšky hlasu, DTW (bez závislostí)
  WakeTemplates.kt  – ukládání vzorků (JSON), práh, porovnání
  ListenService.kt  – služba na popředí: mikrofon, VAD, nahrávání vzorků, reakce (TTS)
  MainActivity.kt   – obrazovka: start/stop, vzorky, nastavení, záznam
  Notifs.kt         – oznámení (trvalé + nabídka po restartu)
  BootReceiver.kt   – po restartu telefonu ukáže nabídku spuštění
  AppBus.kt, Prefs.kt – stav pro UI, uložené nastavení
```

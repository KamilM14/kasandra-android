package cz.kamil.kasandra

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

/**
 * Offline přepis řeči na text (Vosk, český model přibalený v APK jako asset "model-cs").
 * Model se při prvním použití rozbalí do privátní složky aplikace a pak drží v paměti.
 */
object VoskTranscriber {
    private const val ASSET_DIR = "model-cs"
    private const val VERSION_FILE = "model-version.txt"
    private const val MODEL_VERSION = "1"

    @Volatile
    private var model: Model? = null
    private val lock = Any()

    /** Načte model na pozadí (volat při probuzení, ať je připravený, než domluvíš). */
    fun preload(ctx: Context) {
        if (model != null) return
        val app = ctx.applicationContext
        Thread({
            try {
                ensureModel(app)
            } catch (e: Exception) {
                AppBus.log("Model řeči se nepodařilo připravit: ${e.message}")
            }
        }, "vosk-preload").start()
    }

    private fun ensureModel(ctx: Context): Model {
        model?.let { return it }
        synchronized(lock) {
            model?.let { return it }
            val dir = File(ctx.filesDir, ASSET_DIR)
            val marker = File(ctx.filesDir, VERSION_FILE)
            val ok = marker.exists() && marker.readText().trim() == MODEL_VERSION &&
                File(dir, "am/final.mdl").exists()
            if (!ok) {
                AppBus.log("Rozbaluji model rozpoznávání řeči (jen poprvé)…")
                dir.deleteRecursively()
                copyAssetDir(ctx, ASSET_DIR, dir)
                marker.writeText(MODEL_VERSION)
            }
            val m = Model(dir.absolutePath)
            model = m
            AppBus.log("Model řeči připraven.")
            return m
        }
    }

    private fun copyAssetDir(ctx: Context, assetPath: String, target: File) {
        val names = ctx.assets.list(assetPath) ?: return
        target.mkdirs()
        for (name in names) {
            val childAsset = "$assetPath/$name"
            val children = ctx.assets.list(childAsset)
            val out = File(target, name)
            if (children != null && children.isNotEmpty()) {
                copyAssetDir(ctx, childAsset, out)
            } else {
                ctx.assets.open(childAsset).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            }
        }
    }

    /** Blokující přepis úseku PCM16/16 kHz na text. Vrací "" když se nic nerozpoznalo. */
    fun transcribe(ctx: Context, pcm: ShortArray): String {
        val m = try {
            ensureModel(ctx.applicationContext)
        } catch (e: Exception) {
            AppBus.log("Model řeči nedostupný: ${e.message}")
            return ""
        }
        try {
            Recognizer(m, 16000.0f).use { rec ->
                var off = 0
                val chunkSize = 4000
                val chunk = ShortArray(chunkSize)
                while (off < pcm.size) {
                    val n = minOf(chunkSize, pcm.size - off)
                    System.arraycopy(pcm, off, chunk, 0, n)
                    rec.acceptWaveForm(chunk, n)
                    off += n
                }
                val res = rec.finalResult
                return JSONObject(res).optString("text", "").trim()
            }
        } catch (e: Exception) {
            AppBus.log("Přepis selhal: ${e.message}")
            return ""
        }
    }
}

package cz.kamil.kasandra

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Komunikace s backendem Kasandry (POST /chat) po domácí síti. */
object KasandraApi {

    /** Doplní http://, když adresa nemá schéma. */
    private fun normalize(baseUrl: String): String {
        val b = baseUrl.trim().trimEnd('/')
        return if (b.startsWith("http://") || b.startsWith("https://")) b else "http://$b"
    }

    /** Pošle text na POST <base>/chat a vrátí pole "message" z odpovědi. Při chybě vyhazuje výjimku. */
    fun chat(baseUrl: String, text: String): String {
        val url = URL(normalize(baseUrl) + "/chat")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val body = JSONObject().put("text", text).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                throw RuntimeException("HTTP $code: ${resp.take(200)}")
            }
            val message = JSONObject(resp).optString("message", "").trim()
            return message.ifBlank { "Hotovo." }
        } finally {
            conn.disconnect()
        }
    }

    /** Rychlá zkouška, zda server odpovídá. */
    fun ping(baseUrl: String): Boolean {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(normalize(baseUrl) + "/").openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.responseCode in 200..399
        } catch (e: Exception) {
            false
        } finally {
            conn?.disconnect()
        }
    }
}

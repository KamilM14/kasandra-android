package cz.kamil.kasandra

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_AUTOSTART = "autostart"
    }

    private lateinit var statusText: TextView
    private lateinit var promptText: TextView
    private lateinit var startStopButton: Button
    private lateinit var enrollCountText: TextView
    private lateinit var enroll5Button: Button
    private lateinit var enroll1Button: Button
    private lateinit var cancelEnrollButton: Button
    private lateinit var clearVoiceButton: Button
    private lateinit var slackLabel: TextView
    private lateinit var slackSeek: SeekBar
    private lateinit var pitchSwitch: MaterialSwitch
    private lateinit var pitchTolLabel: TextView
    private lateinit var pitchTolSeek: SeekBar
    private lateinit var urlEdit: EditText
    private lateinit var testConnButton: Button
    private lateinit var actionDialog: RadioButton
    private lateinit var actionTest: RadioButton
    private lateinit var actionAssistant: RadioButton
    private lateinit var wakeLockSwitch: MaterialSwitch
    private lateinit var autostartSwitch: MaterialSwitch
    private lateinit var batteryButton: Button
    private lateinit var overlayButton: Button
    private lateinit var logText: TextView

    private var afterPermission: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            val pending = afterPermission
            afterPermission = null
            if (micOk) pending?.invoke()
            else Toast.makeText(this, R.string.perm_denied, Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        promptText = findViewById(R.id.promptText)
        startStopButton = findViewById(R.id.startStopButton)
        enrollCountText = findViewById(R.id.enrollCountText)
        enroll5Button = findViewById(R.id.enroll5Button)
        enroll1Button = findViewById(R.id.enroll1Button)
        cancelEnrollButton = findViewById(R.id.cancelEnrollButton)
        clearVoiceButton = findViewById(R.id.clearVoiceButton)
        slackLabel = findViewById(R.id.slackLabel)
        slackSeek = findViewById(R.id.slackSeek)
        pitchSwitch = findViewById(R.id.pitchSwitch)
        pitchTolLabel = findViewById(R.id.pitchTolLabel)
        pitchTolSeek = findViewById(R.id.pitchTolSeek)
        urlEdit = findViewById(R.id.urlEdit)
        testConnButton = findViewById(R.id.testConnButton)
        actionDialog = findViewById(R.id.actionDialog)
        actionTest = findViewById(R.id.actionTest)
        actionAssistant = findViewById(R.id.actionAssistant)
        wakeLockSwitch = findViewById(R.id.wakeLockSwitch)
        autostartSwitch = findViewById(R.id.autostartSwitch)
        batteryButton = findViewById(R.id.batteryButton)
        overlayButton = findViewById(R.id.overlayButton)
        logText = findViewById(R.id.logText)

        // --- načtení nastavení do UI
        slackSeek.progress = Prefs.slack(this)
        updateSlackLabel(slackSeek.progress)
        pitchSwitch.isChecked = Prefs.pitchCheck(this)
        pitchTolSeek.progress = Prefs.pitchTolerance(this)
        updatePitchTolLabel(pitchTolSeek.progress)
        urlEdit.setText(Prefs.baseUrl(this))
        when (Prefs.action(this)) {
            Prefs.ACTION_ASSISTANT -> actionAssistant.isChecked = true
            Prefs.ACTION_TEST -> actionTest.isChecked = true
            else -> actionDialog.isChecked = true
        }
        wakeLockSwitch.isChecked = Prefs.wakeLock(this)
        autostartSwitch.isChecked = Prefs.autostart(this)
        Thread { AppBus.enrollCount.postValue(WakeTemplates(this).count()) }.start()

        // Edge-to-edge (targetSdk 35): ať spodek seznamu nekončí pod navigační lištou.
        val root = findViewById<View>(R.id.rootScroll)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, bars.bottom)
            insets
        }

        // --- akce
        startStopButton.setOnClickListener {
            if (ListenService.isRunning) ListenService.stop(this)
            else withPermissions { ListenService.start(this) }
        }
        enroll5Button.setOnClickListener { withPermissions { ListenService.enroll(this, 5) } }
        enroll1Button.setOnClickListener { withPermissions { ListenService.enroll(this, 1) } }
        cancelEnrollButton.setOnClickListener { ListenService.cancelEnroll(this) }
        clearVoiceButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Smazat vzorky hlasu?")
                .setMessage("Kasandra pak nebude reagovat, dokud nenahraješ nové vzorky.")
                .setPositiveButton("Smazat") { _, _ ->
                    Thread {
                        WakeTemplates(this).clear()
                        AppBus.enrollCount.postValue(0)
                        AppBus.log("Vzorky smazány.")
                        runOnUiThread { ListenService.reload(this) }
                    }.start()
                }
                .setNegativeButton("Zrušit", null)
                .show()
        }
        slackSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateSlackLabel(progress)
                if (fromUser) Prefs.setSlack(this@MainActivity, progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        pitchSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setPitchCheck(this, checked) }
        pitchTolSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updatePitchTolLabel(progress)
                if (fromUser) Prefs.setPitchTolerance(this@MainActivity, progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        urlEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.setBaseUrl(this@MainActivity, s?.toString() ?: "")
            }
        })
        testConnButton.setOnClickListener {
            val base = Prefs.baseUrl(this)
            if (base.isBlank()) {
                Toast.makeText(this, "Nejdřív vyplň adresu.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            testConnButton.isEnabled = false
            Thread {
                val ok = KasandraApi.ping(base)
                runOnUiThread {
                    testConnButton.isEnabled = true
                    Toast.makeText(
                        this,
                        if (ok) "Kasandra odpovídá ✔" else "Kasandra neodpovídá – zkontroluj adresu, Wi-Fi a že běží run.py.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }.start()
        }
        actionDialog.setOnCheckedChangeListener { _, checked -> if (checked) Prefs.setAction(this, Prefs.ACTION_DIALOG) }
        actionTest.setOnCheckedChangeListener { _, checked -> if (checked) Prefs.setAction(this, Prefs.ACTION_TEST) }
        actionAssistant.setOnCheckedChangeListener { _, checked -> if (checked) Prefs.setAction(this, Prefs.ACTION_ASSISTANT) }
        wakeLockSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setWakeLock(this, checked)
            ListenService.reload(this)
        }
        autostartSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setAutostart(this, checked) }
        batteryButton.setOnClickListener { requestBatteryExemption() }
        overlayButton.setOnClickListener { requestOverlay() }

        // --- sledování stavu služby
        AppBus.running.observe(this) { running ->
            startStopButton.setText(if (running == true) R.string.btn_stop else R.string.btn_start)
        }
        AppBus.status.observe(this) { statusText.text = it }
        AppBus.prompt.observe(this) { p ->
            promptText.text = p ?: ""
            promptText.visibility = if (p == null) View.GONE else View.VISIBLE
            cancelEnrollButton.visibility = if (p == null) View.GONE else View.VISIBLE
        }
        AppBus.enrollCount.observe(this) { enrollCountText.text = "Vzorků: $it" }
        AppBus.log.observe(this) { logText.text = it.joinToString("\n") }

        handleAutostart(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAutostart(intent)
    }

    private fun handleAutostart(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_AUTOSTART, false) == true && !ListenService.isRunning) {
            intent.removeExtra(EXTRA_AUTOSTART)
            withPermissions { ListenService.start(this) }
        }
    }

    private fun updateSlackLabel(v: Int) {
        slackLabel.text = getString(R.string.label_slack) + ": $v %"
    }

    private fun updatePitchTolLabel(v: Int) {
        pitchTolLabel.text = getString(R.string.label_pitch_tol) + ": ±$v %"
    }

    /** Vyžádá oprávnění (mikrofon, oznámení) a pak spustí akci. */
    private fun withPermissions(block: () -> Unit) {
        val needed = ArrayList<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isEmpty()) {
            block()
        } else {
            afterPermission = block
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Kasandra už je z optimalizace baterie vyjmuta.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "Nastavení baterie se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Zobrazení přes jiné aplikace je už povoleno.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(this, "Nastavení se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
        }
    }
}

package cz.kamil.kasandra

import androidx.lifecycle.MutableLiveData
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Jednoduchý most služba → obrazovka (LiveData, bezpečné z jiných vláken přes postValue). */
object AppBus {
    val running = MutableLiveData(false)
    val status = MutableLiveData("Zastaveno")
    /** Text výzvy při nahrávání vzorků (null = nenahrává se). */
    val prompt = MutableLiveData<String?>(null)
    val enrollCount = MutableLiveData(0)
    val log = MutableLiveData<List<String>>(emptyList())

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val lines = ArrayList<String>()
    private const val MAX_LINES = 80

    fun log(msg: String) {
        val snapshot: List<String>
        synchronized(lines) {
            lines.add(0, "${fmt.format(Date())}  $msg")
            while (lines.size > MAX_LINES) lines.removeAt(lines.size - 1)
            snapshot = ArrayList(lines)
        }
        log.postValue(snapshot)
    }
}

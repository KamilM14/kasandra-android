package cz.kamil.kasandra

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val ACTION_TEST = "test"
    const val ACTION_ASSISTANT = "assistant"
    const val ACTION_DIALOG = "dialog"

    private fun p(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("kasandra", Context.MODE_PRIVATE)

    /** Adresa backendu Kasandry v domácí síti, např. http://192.168.1.50:8000 */
    fun baseUrl(ctx: Context): String = p(ctx).getString("base_url", "") ?: ""
    fun setBaseUrl(ctx: Context, v: String) = p(ctx).edit().putString("base_url", v.trim()).apply()

    /** Tolerance shody v % (0 = velmi přísné, 100 = velmi benevolentní). */
    fun slack(ctx: Context): Int = p(ctx).getInt("slack", 40)
    fun setSlack(ctx: Context, v: Int) = p(ctx).edit().putInt("slack", v).apply()

    fun action(ctx: Context): String = p(ctx).getString("action", ACTION_DIALOG) ?: ACTION_DIALOG
    fun setAction(ctx: Context, v: String) = p(ctx).edit().putString("action", v).apply()

    /** Kontrolovat i výšku hlasu (F0) proti vzorkům. */
    fun pitchCheck(ctx: Context): Boolean = p(ctx).getBoolean("pitch_check", true)
    fun setPitchCheck(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("pitch_check", v).apply()

    /** Povolená odchylka výšky hlasu v % (např. 30 = ±30 %). */
    fun pitchTolerance(ctx: Context): Int = p(ctx).getInt("pitch_tol", 30)
    fun setPitchTolerance(ctx: Context, v: Int) = p(ctx).edit().putInt("pitch_tol", v).apply()

    fun wakeLock(ctx: Context): Boolean = p(ctx).getBoolean("wakelock", false)
    fun setWakeLock(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("wakelock", v).apply()

    fun autostart(ctx: Context): Boolean = p(ctx).getBoolean("autostart", true)
    fun setAutostart(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("autostart", v).apply()
}

package cz.kamil.kasandra

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

object Notifs {
    const val CHANNEL_LISTEN = "kasandra_listen"
    const val CHANNEL_INFO = "kasandra_info"
    const val ID_LISTEN = 1
    const val ID_OFFER = 2

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL_LISTEN) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_LISTEN, ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                }
            )
        }
        if (nm.getNotificationChannel(CHANNEL_INFO) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_INFO, "Kasandra – upozornění", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    private fun openAppIntent(ctx: Context, autostart: Boolean): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_AUTOSTART, autostart)
        return PendingIntent.getActivity(
            ctx, if (autostart) 11 else 10, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Trvalé oznámení služby na popředí. */
    fun listening(ctx: Context, text: String): Notification {
        ensureChannels(ctx)
        val stop = PendingIntent.getService(
            ctx, 20,
            Intent(ctx, ListenService::class.java).setAction(ListenService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(ctx, CHANNEL_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(ctx.getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openAppIntent(ctx, false))
            .addAction(0, ctx.getString(R.string.notif_stop), stop)
            .build()
    }

    /** Po restartu telefonu: nabídka „ťukni pro spuštění“ (mikrofon nelze z pozadí spustit sám). */
    fun showOffer(ctx: Context) {
        ensureChannels(ctx)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(ctx, CHANNEL_INFO)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(ctx.getString(R.string.notif_boot_title))
            .setContentText(ctx.getString(R.string.notif_boot_text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx, true))
            .build()
        ctx.getSystemService(NotificationManager::class.java)?.notify(ID_OFFER, n)
    }
}

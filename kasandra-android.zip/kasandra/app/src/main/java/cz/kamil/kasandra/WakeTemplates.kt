package cz.kamil.kasandra

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Uložené vzorky (šablony) slova „kasandro“ – MFCC sekvence z vlastního hlasu
 * + výška hlasu (F0) každého vzorku.
 * Obdoba wake_templates.npz z PC verze; tady JSON soubor v privátní složce aplikace.
 */
class WakeTemplates(private val ctx: Context) {

    private val file: File get() = File(ctx.filesDir, "wake_templates.json")

    private val lock = Any()
    private var templates: MutableList<Array<DoubleArray>> = mutableListOf()
    private var pitches: MutableList<Double> = mutableListOf()
    private var maxPair = 0.0
    private var meanPair = 0.0

    init {
        reload()
    }

    fun count(): Int = synchronized(lock) { templates.size }

    fun reload() {
        synchronized(lock) {
            load()
            recomputeStats()
        }
    }

    fun add(t: Array<DoubleArray>, f0: Double) {
        synchronized(lock) {
            templates.add(t)
            pitches.add(f0)
            recomputeStats()
            save()
        }
    }

    fun clear() {
        synchronized(lock) {
            templates.clear()
            pitches.clear()
            recomputeStats()
            save()
        }
    }

    /** Největší vzájemná DTW vzdálenost mezi vzorky (základ pro práh). */
    fun maxPairwise(): Double = synchronized(lock) { maxPair }
    fun meanPairwise(): Double = synchronized(lock) { meanPair }

    /** Medián výšky hlasu ze vzorků (Hz); 0 = neznámo. */
    fun medianPitch(): Double = synchronized(lock) {
        val v = pitches.filter { it > 0 }.sorted()
        if (v.isEmpty()) 0.0 else v[v.size / 2]
    }

    /**
     * Práh detekce: největší vzájemná vzdálenost vzorků zvětšená o toleranci (v %).
     * S méně než 2 vzorky nelze práh spočítat → vrací 0 (nikdy se nespustí).
     */
    fun threshold(slackPercent: Int): Double = synchronized(lock) {
        if (templates.size < 2) return 0.0
        maxPair * (1.0 + slackPercent / 100.0) + 0.5
    }

    /** Nejmenší DTW vzdálenost zachyceného úseku od kteréhokoliv vzorku. */
    fun bestDistance(m: Array<DoubleArray>): Double = synchronized(lock) {
        var best = Double.POSITIVE_INFINITY
        for (t in templates) {
            val d = Dsp.dtw(m, t)
            if (d < best) best = d
        }
        best
    }

    private fun recomputeStats() {
        var mx = 0.0
        var sum = 0.0
        var cnt = 0
        for (a in templates.indices) {
            for (b in a + 1 until templates.size) {
                val d = Dsp.dtw(templates[a], templates[b])
                if (d > mx) mx = d
                sum += d
                cnt++
            }
        }
        maxPair = mx
        meanPair = if (cnt > 0) sum / cnt else 0.0
    }

    private fun save() {
        val arr = JSONArray()
        val f0s = JSONArray()
        for (i in templates.indices) {
            val frames = JSONArray()
            for (fr in templates[i]) {
                val row = JSONArray()
                for (v in fr) row.put(v)
                frames.put(row)
            }
            arr.put(frames)
            f0s.put(pitches.getOrElse(i) { 0.0 })
        }
        val root = JSONObject()
        root.put("version", 2)
        root.put("templates", arr)
        root.put("f0", f0s)
        try {
            file.writeText(root.toString())
        } catch (e: Exception) {
            AppBus.log("Vzorky se nepodařilo uložit: ${e.message}")
        }
    }

    private fun load() {
        templates = mutableListOf()
        pitches = mutableListOf()
        if (!file.exists()) return
        try {
            val root = JSONObject(file.readText())
            val arr = root.getJSONArray("templates")
            val f0s = root.optJSONArray("f0")
            for (i in 0 until arr.length()) {
                val frames = arr.getJSONArray(i)
                val t = Array(frames.length()) { f ->
                    val row = frames.getJSONArray(f)
                    DoubleArray(row.length()) { k -> row.getDouble(k) }
                }
                if (t.isNotEmpty()) {
                    templates.add(t)
                    pitches.add(if (f0s != null && i < f0s.length()) f0s.optDouble(i, 0.0) else 0.0)
                }
            }
        } catch (e: Exception) {
            AppBus.log("Vzorky se nepodařilo načíst: ${e.message}")
        }
    }
}

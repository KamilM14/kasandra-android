package cz.kamil.kasandra

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Po restartu telefonu (nebo aktualizaci aplikace) nelze na novějších Androidech spustit
 * službu s mikrofonem z pozadí – ukážeme tedy oznámení, jedním ťuknutím se poslech obnoví.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                if (Prefs.autostart(context)) Notifs.showOffer(context)
            }
        }
    }
}

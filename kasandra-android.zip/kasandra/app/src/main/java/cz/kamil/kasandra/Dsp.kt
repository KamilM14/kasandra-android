package cz.kamil.kasandra

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Čistě matematická část bez závislostí: RMS, ořez ticha, FFT, MFCC a DTW.
 * Je to obdoba toho, co v PC verzi dělala librosa (mfcc + effects.trim + sequence.dtw).
 */
object Dsp {
    const val SAMPLE_RATE = 16000

    private const val FRAME = 400      // 25 ms
    private const val HOP = 160        // 10 ms
    private const val NFFT = 512
    private const val NBINS = NFFT / 2 + 1
    private const val NMEL = 26
    /** Počet kepstrálních koeficientů na rámec (c1..c12; c0 = hlasitost vynecháváme). */
    const val NCEP = 12

    private val window = DoubleArray(FRAME) { 0.54 - 0.46 * cos(2.0 * PI * it / (FRAME - 1)) }
    private val melFilters: Array<DoubleArray> = buildMelFilters()

    /** DCT-II s ortonormální normalizací, řádky pro k = 1..NCEP. */
    private val dct: Array<DoubleArray> = Array(NCEP) { i ->
        val k = i + 1
        DoubleArray(NMEL) { m -> sqrt(2.0 / NMEL) * cos(PI * k * (m + 0.5) / NMEL) }
    }

    private fun hzToMel(f: Double): Double = 2595.0 * log10(1.0 + f / 700.0)
    private fun melToHz(m: Double): Double = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

    private fun buildMelFilters(): Array<DoubleArray> {
        val lo = hzToMel(60.0)
        val hi = hzToMel(7600.0)
        val hz = DoubleArray(NMEL + 2) { melToHz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) {
            floor((NFFT + 1) * hz[it] / SAMPLE_RATE).toInt().coerceIn(0, NBINS - 1)
        }
        return Array(NMEL) { m ->
            val f = DoubleArray(NBINS)
            val a = bins[m]
            val b = bins[m + 1]
            val c = bins[m + 2]
            for (k in a until b) f[k] = (k - a).toDouble() / max(1, b - a)
            for (k in b until c) f[k] = (c - k).toDouble() / max(1, c - b)
            f
        }
    }

    /** Iterativní FFT (radix-2) na místě. Délka polí musí být mocnina dvou. */
    fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang)
            val wi = kotlin.math.sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                val half = len / 2
                for (k in 0 until half) {
                    val a = i + k
                    val b = a + half
                    val xr = re[b] * cr - im[b] * ci
                    val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr
                    im[b] = im[a] - xi
                    re[a] += xr
                    im[a] += xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** RMS hlasitost bloku PCM16. */
    fun rms(buf: ShortArray, n: Int): Double {
        if (n <= 0) return 0.0
        var s = 0.0
        for (i in 0 until n) {
            val v = buf[i].toDouble()
            s += v * v
        }
        return sqrt(s / n)
    }

    /** Ořízne ticho na začátku a konci úseku (obdoba librosa.effects.trim s top_db). */
    fun trim(pcm: ShortArray, topDb: Double = 32.0): ShortArray {
        val fl = 480
        if (pcm.size < fl * 2) return pcm
        val nf = pcm.size / fl
        val e = DoubleArray(nf) { f -> rmsRange(pcm, f * fl, fl) }
        val peak = e.maxOrNull() ?: 0.0
        if (peak <= 0.0) return pcm
        val thr = peak / 10.0.pow(topDb / 20.0)
        var first = 0
        while (first < nf && e[first] < thr) first++
        var last = nf - 1
        while (last > first && e[last] < thr) last--
        val start = first * fl
        val end = min(pcm.size, (last + 1) * fl)
        return if (end > start) pcm.copyOfRange(start, end) else pcm
    }

    private fun rmsRange(pcm: ShortArray, off: Int, len: Int): Double {
        var s = 0.0
        for (i in off until off + len) {
            val v = pcm[i].toDouble()
            s += v * v
        }
        return sqrt(s / len)
    }

    /** MFCC: vrátí pole rámců, každý rámec má NCEP hodnot. */
    fun mfcc(pcm: ShortArray): Array<DoubleArray> {
        if (pcm.size < FRAME) return emptyArray()
        val nFrames = (pcm.size - FRAME) / HOP + 1
        val re = DoubleArray(NFFT)
        val im = DoubleArray(NFFT)
        val power = DoubleArray(NBINS)
        val logMel = DoubleArray(NMEL)
        return Array(nFrames) { f ->
            val off = f * HOP
            var prev = if (off > 0) pcm[off - 1].toDouble() else 0.0
            for (i in 0 until FRAME) {
                val s = pcm[off + i].toDouble()
                re[i] = (s - 0.97 * prev) * window[i]   // pre-emfáze + Hammingovo okno
                im[i] = 0.0
                prev = s
            }
            for (i in FRAME until NFFT) {
                re[i] = 0.0
                im[i] = 0.0
            }
            fft(re, im)
            for (k in 0 until NBINS) power[k] = (re[k] * re[k] + im[k] * im[k]) / NFFT
            for (m in 0 until NMEL) {
                val filt = melFilters[m]
                var s = 0.0
                for (k in 0 until NBINS) s += filt[k] * power[k]
                logMel[m] = 10.0 * log10(max(s, 1e-3))   // dB, jako librosa power_to_db
            }
            DoubleArray(NCEP) { c ->
                val row = dct[c]
                var s = 0.0
                for (m in 0 until NMEL) s += row[m] * logMel[m]
                s
            }
        }
    }

    /**
     * Odhad základní frekvence hlasu (F0, „výška hlasu“) v Hz – medián přes znělé rámce.
     * Autokorelace na 40ms rámcích; vrací 0, když se nepodařilo nic spolehlivě určit.
     */
    fun pitch(pcm: ShortArray): Double {
        val fl = 640
        val hop = 320
        if (pcm.size < fl) return 0.0
        val nf = (pcm.size - fl) / hop + 1
        val energies = DoubleArray(nf) { rmsRange(pcm, it * hop, fl) }
        val peak = energies.maxOrNull() ?: return 0.0
        if (peak <= 0.0) return 0.0
        val minLag = SAMPLE_RATE / 400   // 400 Hz
        val maxLag = SAMPLE_RATE / 60    // 60 Hz
        val x = DoubleArray(fl)
        val cum = DoubleArray(fl + 1)    // kumulativní součet čtverců pro normalizaci
        val f0s = ArrayList<Double>()
        for (f in 0 until nf) {
            if (energies[f] < peak * 0.3) continue
            val off = f * hop
            var mean = 0.0
            for (i in 0 until fl) mean += pcm[off + i]
            mean /= fl
            for (i in 0 until fl) {
                x[i] = pcm[off + i] - mean
                cum[i + 1] = cum[i] + x[i] * x[i]
            }
            val r = DoubleArray(maxLag + 1)
            var bestLag = 0
            var bestR = 0.0
            for (lag in minLag..maxLag) {
                var s = 0.0
                val n = fl - lag
                for (i in 0 until n) s += x[i] * x[i + lag]
                val e1 = cum[n]
                val e2 = cum[fl] - cum[lag]
                val rn = if (e1 > 0 && e2 > 0) s / sqrt(e1 * e2) else 0.0
                r[lag] = rn
                if (rn > bestR) {
                    bestR = rn
                    bestLag = lag
                }
            }
            if (bestLag == 0 || bestR < 0.5) continue
            // oprava oktávové chyby: když je poloviční perioda skoro stejně dobrá, je to ona
            val half = bestLag / 2
            if (half >= minLag && r[half] > 0.8 * bestR) bestLag = half
            f0s.add(SAMPLE_RATE.toDouble() / bestLag)
        }
        if (f0s.size < 3) return 0.0
        f0s.sort()
        return f0s[f0s.size / 2]
    }

    /**
     * DTW vzdálenost dvou MFCC sekvencí, normalizovaná součtem délek
     * (stejně jako v PC verzi: D[-1,-1] / (n + m)).
     */
    fun dtw(a: Array<DoubleArray>, b: Array<DoubleArray>): Double {
        val n = a.size
        val m = b.size
        if (n == 0 || m == 0) return Double.POSITIVE_INFINITY
        var prev = DoubleArray(m + 1) { Double.POSITIVE_INFINITY }
        var cur = DoubleArray(m + 1)
        prev[0] = 0.0
        for (i in 1..n) {
            cur[0] = Double.POSITIVE_INFINITY
            val ai = a[i - 1]
            for (j in 1..m) {
                val bj = b[j - 1]
                var d = 0.0
                for (k in ai.indices) {
                    val x = ai[k] - bj[k]
                    d += x * x
                }
                val best = min(prev[j - 1], min(prev[j], cur[j - 1]))
                cur[j] = sqrt(d) + best
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[m] / (n + m)
    }
}

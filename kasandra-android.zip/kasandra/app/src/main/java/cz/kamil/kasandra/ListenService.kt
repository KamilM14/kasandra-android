package cz.kamil.kasandra

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.max

/**
 * Služba na popředí, která trvale poslouchá mikrofon a hledá slovo „kasandro“.
 *
 * Princip (stejný jako v PC verzi voice_control.py):
 *  1. Každých 30 ms spočítá jen RMS hlasitost (téměř nulová zátěž → nízká spotřeba).
 *  2. Když hlasitost přeskočí adaptivní šumový práh, začne sbírat úsek řeči,
 *     dokud nenastane 500 ms ticha (max 2,5 s).
 *  3. Úsek ořízne, spočítá MFCC a porovná DTW se vzorky vlastního hlasu.
 *  4. Pod prahem → aktivace (testovací hláška / spuštění asistenta).
 */
class ListenService : Service() {

    companion object {
        const val ACTION_START = "cz.kamil.kasandra.action.START"
        const val ACTION_STOP = "cz.kamil.kasandra.action.STOP"
        const val ACTION_ENROLL = "cz.kamil.kasandra.action.ENROLL"
        const val ACTION_CANCEL_ENROLL = "cz.kamil.kasandra.action.CANCEL_ENROLL"
        const val ACTION_RELOAD = "cz.kamil.kasandra.action.RELOAD"
        const val EXTRA_ENROLL_COUNT = "enroll_count"

        private const val SR = Dsp.SAMPLE_RATE
        private const val FRAME = 480                 // 30 ms
        // režim čekání na "kasandro"
        private const val SILENCE_HANG_FRAMES = 500 / 30
        private const val MAX_SEGMENT_FRAMES = (2500 / 30)
        private const val MIN_SEGMENT_S = 0.45
        // režim příkazu (dialog s Kasandrou)
        private const val CMD_SILENCE_HANG_FRAMES = 800 / 30
        private const val CMD_MAX_SEGMENT_FRAMES = (12000 / 30)
        private const val CMD_MIN_SEGMENT_S = 0.25
        private const val CMD_LISTEN_WINDOW_MS = 8000L
        private const val MAX_DIALOG_TURNS = 6

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, intent(ctx, ACTION_START))
        }

        fun stop(ctx: Context) {
            if (isRunning) safeStart(ctx, intent(ctx, ACTION_STOP))
        }

        fun enroll(ctx: Context, count: Int) {
            ContextCompat.startForegroundService(
                ctx, intent(ctx, ACTION_ENROLL).putExtra(EXTRA_ENROLL_COUNT, count)
            )
        }

        fun cancelEnroll(ctx: Context) {
            if (isRunning) safeStart(ctx, intent(ctx, ACTION_CANCEL_ENROLL))
        }

        fun reload(ctx: Context) {
            if (isRunning) safeStart(ctx, intent(ctx, ACTION_RELOAD))
        }

        private fun intent(ctx: Context, action: String): Intent =
            Intent(ctx, ListenService::class.java).setAction(action)

        private fun safeStart(ctx: Context, i: Intent) {
            try {
                ctx.startService(i)
            } catch (e: Exception) {
                AppBus.log("Příkaz službě selhal: ${e.javaClass.simpleName}")
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var thread: Thread? = null

    @Volatile private var stopRequested = false
    @Volatile private var enrollRemaining = 0
    @Volatile private var enrollTotal = 0
    @Volatile private var reloadRequested = false
    /** Během přehrávání hlášky mikrofon ignorujeme (jinak bychom slyšeli sami sebe). */
    @Volatile private var muted = false
    /** Do tohoto času (ms) ignorujeme vstup – krátká pauza po aktivaci / hlášce. */
    @Volatile private var skipUntil = 0L

    private enum class Mode { WAKE, COMMAND }

    /** WAKE = čeká na „kasandro“, COMMAND = probíhá dialog s Kasandrou. */
    @Volatile private var mode = Mode.WAKE
    /** V režimu COMMAND: do kdy čekáme, že začneš mluvit. */
    @Volatile private var commandDeadline = 0L
    /** Kontext dialogu – původní příkaz, ke kterému se lepí upřesnění. */
    @Volatile private var dialogContext: String? = null
    @Volatile private var dialogTurns = 0
    /** Po dokončení právě přehrávané hlášky dialog ukončit. */
    @Volatile private var endAfterSpeak = false
    /** Počet po sobě jdoucích nesrozumitelných úseků v dialogu. */
    @Volatile private var failedTranscriptions = 0
    /** Tento dialog používá vestavěné rozpoznávání telefonu (jinak offline Vosk). */
    @Volatile private var dialogUsesGoogle = false
    /** Audio smyčka má pustit mikrofon (běží vestavěné rozpoznávání). */
    @Volatile private var micPaused = false
    @Volatile private var googleListening = false
    private var speechRecognizer: SpeechRecognizer? = null

    private lateinit var templates: WakeTemplates
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var persistentLock: PowerManager.WakeLock? = null
    private var shortLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        templates = WakeTemplates(this)
        Notifs.ensureChannels(this)
        val pm = getSystemService(PowerManager::class.java)
        persistentLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Kasandra:listen")
        shortLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Kasandra:wake")
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListening()
                return START_NOT_STICKY
            }
            ACTION_ENROLL -> {
                if (!ensureListening()) return START_NOT_STICKY
                val n = (intent?.getIntExtra(EXTRA_ENROLL_COUNT, 1) ?: 1).coerceIn(1, 20)
                enrollTotal = n
                enrollRemaining = n
                AppBus.prompt.postValue("Vzorek 1/$n – řekni: „kasandro“")
                AppBus.log("Nahrávám $n vzorků. Mluv normálně, po slově udělej pauzu.")
            }
            ACTION_CANCEL_ENROLL -> {
                if (enrollRemaining > 0) {
                    enrollRemaining = 0
                    AppBus.prompt.postValue(null)
                    AppBus.log("Nahrávání vzorků zrušeno.")
                }
            }
            ACTION_RELOAD -> {
                reloadRequested = true
                applyWakeLockPref()
            }
            else -> {
                if (intent == null) {
                    // Restart služby systémem = start z pozadí; mikrofon bychom nedostali.
                    // Nabídneme spuštění ťuknutím na oznámení.
                    Notifs.showOffer(this)
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (!ensureListening()) return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopRequested = true
        isRunning = false
        micPaused = false
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        releaseLocks()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        AppBus.running.postValue(false)
        AppBus.status.postValue(getString(R.string.status_stopped))
        AppBus.prompt.postValue(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ start / stop

    private fun ensureListening(): Boolean {
        if (isRunning) return true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            AppBus.log(getString(R.string.perm_denied))
            stopSelf()
            return false
        }
        try {
            val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            ServiceCompat.startForeground(this, Notifs.ID_LISTEN, Notifs.listening(this, "Naslouchám na „kasandro“"), type)
        } catch (e: Exception) {
            // Typicky: pokus o start z pozadí (po restartu apod.) – nabídneme spuštění ťuknutím.
            AppBus.log("Službu nelze spustit z pozadí (${e.javaClass.simpleName}).")
            Notifs.showOffer(this)
            stopSelf()
            return false
        }
        thread?.let { if (it.isAlive) it.join(400) }
        stopRequested = false
        isRunning = true
        AppBus.running.postValue(true)
        AppBus.status.postValue("Naslouchám na „kasandro“")
        AppBus.enrollCount.postValue(templates.count())
        applyWakeLockPref()
        thread = Thread({ audioLoop() }, "kasandra-audio").also { it.start() }
        return true
    }

    private fun stopListening() {
        stopRequested = true
        enrollRemaining = 0
        isRunning = false
        mode = Mode.WAKE
        dialogContext = null
        endAfterSpeak = false
        googleListening = false
        micPaused = false
        handler.removeCallbacks(googleTimeout)
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {
        }
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        releaseLocks()
        AppBus.running.postValue(false)
        AppBus.status.postValue(getString(R.string.status_stopped))
        AppBus.prompt.postValue(null)
        AppBus.log("Naslouchání zastaveno.")
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun applyWakeLockPref() {
        val lock = persistentLock ?: return
        try {
            if (Prefs.wakeLock(this)) {
                if (!lock.isHeld) {
                    lock.acquire()
                    AppBus.log("Wake lock zapnut.")
                }
            } else if (lock.isHeld) {
                lock.release()
                AppBus.log("Wake lock vypnut.")
            }
        } catch (e: Exception) {
            AppBus.log("Wake lock: ${e.message}")
        }
    }

    private fun releaseLocks() {
        try {
            persistentLock?.let { if (it.isHeld) it.release() }
            shortLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ audio smyčka

    @SuppressLint("MissingPermission")
    private fun audioLoop() {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufBytes = max(minBuf, SR * 2)   // ~1 s vyrovnávací paměti (v bajtech)
        val rec: AudioRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes
            )
        } catch (e: Exception) {
            fail("Mikrofon se nepodařilo otevřít: ${e.message}")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            fail("Mikrofon není k dispozici (AudioRecord neinicializován).")
            return
        }
        try {
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                fail("Mikrofon nezačal nahrávat (používá ho jiná aplikace?).")
                return
            }
            AppBus.log("Mikrofon otevřen, poslouchám.")

            val buf = ShortArray(FRAME)
            val prevBuf = ShortArray(FRAME)      // 1 rámec „před“ řečí, aby se neuřízl začátek slova
            var prevLen = 0
            val seg = ShortArray(FRAME * (CMD_MAX_SEGMENT_FRAMES + 3))
            var segLen = 0
            var segFrames = 0
            var inSpeech = false
            var silenceRun = 0
            var noise = 150.0

            while (!stopRequested && Thread.currentThread() === thread) {
                if (micPaused) {
                    // běží vestavěné rozpoznávání – pustíme mikrofon a počkáme
                    try {
                        if (rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) rec.stop()
                    } catch (_: Exception) {
                    }
                    while (micPaused && !stopRequested && Thread.currentThread() === thread) {
                        Thread.sleep(50)
                    }
                    if (stopRequested || Thread.currentThread() !== thread) break
                    try {
                        rec.startRecording()
                    } catch (e: Exception) {
                        fail("Mikrofon se nepodařilo obnovit: ${e.message}")
                        return
                    }
                    inSpeech = false
                    segLen = 0
                    segFrames = 0
                    prevLen = 0
                    continue
                }
                if (reloadRequested) {
                    reloadRequested = false
                    templates.reload()
                    AppBus.enrollCount.postValue(templates.count())
                }
                val n = rec.read(buf, 0, FRAME)
                if (n < 0) {
                    fail("Chyba čtení mikrofonu ($n).")
                    return
                }
                if (n == 0) continue

                if (muted || System.currentTimeMillis() < skipUntil) {
                    inSpeech = false
                    segLen = 0
                    segFrames = 0
                    prevLen = 0
                    continue
                }

                val level = Dsp.rms(buf, n)

                if (!inSpeech) {
                    // dialog: když v čekacím okně nezačneš mluvit, vrátíme se k čekání na "kasandro"
                    if (mode == Mode.COMMAND && System.currentTimeMillis() > commandDeadline) {
                        commandDeadline = Long.MAX_VALUE
                        handler.post {
                            if (mode == Mode.COMMAND && !muted) {
                                AppBus.log("Nic dalšího jsem neslyšela.")
                                endDialog()
                            }
                        }
                        continue
                    }
                    noise = noise * 0.95 + level * 0.05
                    if (level > noise * 3.0 + 150.0) {
                        inSpeech = true
                        silenceRun = 0
                        System.arraycopy(prevBuf, 0, seg, 0, prevLen)
                        System.arraycopy(buf, 0, seg, prevLen, n)
                        segLen = prevLen + n
                        segFrames = 1
                        prevLen = 0
                    } else {
                        System.arraycopy(buf, 0, prevBuf, 0, n)
                        prevLen = n
                    }
                    continue
                }

                // uvnitř řeči
                if (segLen + n <= seg.size) {
                    System.arraycopy(buf, 0, seg, segLen, n)
                    segLen += n
                }
                segFrames++
                if (level < noise * 2.0 + 80.0) silenceRun++ else silenceRun = 0

                val inCommand = mode == Mode.COMMAND
                val hangFrames = if (inCommand) CMD_SILENCE_HANG_FRAMES else SILENCE_HANG_FRAMES
                val maxFrames = if (inCommand) CMD_MAX_SEGMENT_FRAMES else MAX_SEGMENT_FRAMES
                val finalize = silenceRun >= hangFrames || segFrames >= maxFrames
                if (!finalize) continue

                inSpeech = false
                val pcm = seg.copyOf(segLen)
                segLen = 0
                segFrames = 0
                val duration = pcm.size.toDouble() / SR
                // délka samotné řeči (bez koncového ticha, které úsek uzavřelo)
                val speechS = duration - silenceRun * FRAME.toDouble() / SR
                if (speechS < (if (inCommand) CMD_MIN_SEGMENT_S else MIN_SEGMENT_S)) continue

                val handled = if (inCommand) handleCommandSegment(pcm) else handleSegment(pcm, speechS)
                if (handled) {
                    skipUntil = System.currentTimeMillis() + if (inCommand) 400 else 1200
                    noise = max(noise, 150.0)
                }
            }
        } finally {
            try {
                rec.stop()
            } catch (_: Exception) {
            }
            rec.release()
        }
    }

    private fun fail(msg: String) {
        AppBus.log(msg)
        handler.post { if (isRunning) stopListening() }
    }

    /** Vrátí true, když se má po úseku chvíli neposlouchat (aktivace nebo uložený vzorek). */
    private fun handleSegment(pcm: ShortArray, duration: Double): Boolean {
        val trimmed = Dsp.trim(pcm)
        val m = Dsp.mfcc(trimmed)
        if (m.size < 5) return false
        val f0 = Dsp.pitch(trimmed)

        if (enrollRemaining > 0) {
            templates.add(m, f0)
            enrollRemaining--
            val done = enrollTotal - enrollRemaining
            AppBus.enrollCount.postValue(templates.count())
            AppBus.log(
                "Vzorek %d/%d uložen (%.2f s, %d rámců, výška hlasu %.0f Hz).".format(
                    Locale.US, done, enrollTotal, duration, m.size, f0
                )
            )
            vibrate(60)
            if (enrollRemaining > 0) {
                AppBus.prompt.postValue("Vzorek ${done + 1}/$enrollTotal – řekni: „kasandro“")
            } else {
                AppBus.prompt.postValue(null)
                AppBus.log(
                    "Hotovo. Vzorků celkem: %d, práh detekce %.1f (rozptyl vzorků %.1f), výška hlasu ~%.0f Hz.".format(
                        Locale.US, templates.count(), templates.threshold(Prefs.slack(this)),
                        templates.maxPairwise(), templates.medianPitch()
                    )
                )
            }
            return true
        }

        if (templates.count() < 2) {
            AppBus.log("Slyším řeč, ale nemám dost vzorků (potřebuji aspoň 2).")
            return false
        }

        val dist = templates.bestDistance(m)
        val thr = templates.threshold(Prefs.slack(this))
        val wordOk = dist < thr

        // Druhá, levná kontrola: výška hlasu musí zhruba odpovídat mým vzorkům.
        val refF0 = templates.medianPitch()
        val tol = 1.0 + Prefs.pitchTolerance(this) / 100.0
        val pitchOk = !Prefs.pitchCheck(this) || refF0 <= 0.0 || f0 <= 0.0 ||
            (f0 / refF0 in (1.0 / tol)..tol)

        val hit = wordOk && pitchOk
        AppBus.log(
            "%s vzdálenost %.1f / práh %.1f, výška %.0f Hz (moje ~%.0f)%s (%.2f s)".format(
                Locale.US, if (hit) "✔" else "·", dist, thr, f0, refF0,
                if (wordOk && !pitchOk) " – jiný hlas" else "", duration
            )
        )
        if (hit) {
            handler.post { onWake() }
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ reakce

    private fun onWake() {
        AppBus.log("★ „KASANDRO“ zachyceno!")
        vibrate(200)
        try {
            shortLock?.acquire(120_000L)
        } catch (_: Exception) {
        }
        when (Prefs.action(this)) {
            Prefs.ACTION_ASSISTANT -> launchAssistant()
            Prefs.ACTION_DIALOG -> startDialog()
            else -> speak(getString(R.string.wake_reply))
        }
    }

    // ------------------------------------------------------------------ dialog s Kasandrou

    private fun startDialog() {
        val wantGoogle = Prefs.sttEngine(this) == Prefs.STT_GOOGLE
        dialogUsesGoogle = wantGoogle && SpeechRecognizer.isRecognitionAvailable(this)
        if (wantGoogle && !dialogUsesGoogle) {
            AppBus.log("Rozpoznávání telefonu není dostupné – používám offline Vosk.")
        }
        if (!dialogUsesGoogle) VoskTranscriber.preload(this)
        dialogContext = null
        dialogTurns = 0
        failedTranscriptions = 0
        endAfterSpeak = false
        commandDeadline = System.currentTimeMillis() + 15_000
        mode = Mode.COMMAND
        AppBus.status.postValue("Poslouchám příkaz…")
        if (!speak("Ano?")) {
            if (dialogUsesGoogle) startGoogleListening()
            else commandDeadline = System.currentTimeMillis() + CMD_LISTEN_WINDOW_MS
        }
    }

    // ---- vestavěné rozpoznávání telefonu (Google) ----

    private val googleTimeout = Runnable {
        if (googleListening) {
            googleListening = false
            try {
                speechRecognizer?.cancel()
            } catch (_: Exception) {
            }
            AppBus.log("Rozpoznávání vypršelo.")
            endDialog()
        }
    }

    /** Spustí naslouchání vestavěným rozpoznáváním (vždy na hlavním vlákně). */
    private fun startGoogleListening() {
        handler.post {
            if (mode != Mode.COMMAND || stopRequested || googleListening) return@post
            val sr = speechRecognizer ?: try {
                SpeechRecognizer.createSpeechRecognizer(this).also {
                    it.setRecognitionListener(googleListener)
                    speechRecognizer = it
                }
            } catch (e: Exception) {
                AppBus.log("Rozpoznávání nelze vytvořit: ${e.message}")
                endDialog()
                return@post
            }
            micPaused = true               // audio smyčka pustí mikrofon
            googleListening = true
            commandDeadline = Long.MAX_VALUE
            AppBus.status.postValue("Poslouchám…")
            // krátká pauza, ať se mikrofon stihne uvolnit
            handler.postDelayed({
                if (!googleListening || stopRequested) return@postDelayed
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "cs-CZ")
                    .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                try {
                    sr.startListening(i)
                    handler.removeCallbacks(googleTimeout)
                    handler.postDelayed(googleTimeout, 20_000)
                } catch (e: Exception) {
                    AppBus.log("Rozpoznávání se nepodařilo spustit: ${e.message}")
                    googleListening = false
                    endDialog()
                }
            }, 200)
        }
    }

    private val googleListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onEndOfSpeech() {
            AppBus.status.postValue("Rozumím ti…")
        }

        override fun onError(error: Int) {
            handler.removeCallbacks(googleTimeout)
            if (!googleListening) return
            googleListening = false
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> handleGoogleNoMatch()
                else -> {
                    AppBus.log("Chyba rozpoznávání (kód $error).")
                    endDialog()
                }
            }
        }

        override fun onResults(results: Bundle?) {
            handler.removeCallbacks(googleTimeout)
            if (!googleListening) return
            googleListening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim().orEmpty()
            if (text.isBlank()) {
                handleGoogleNoMatch()
                return
            }
            failedTranscriptions = 0
            AppBus.log("Ty: $text")
            Thread({ processCommandText(text) }, "kasandra-cmd").start()
        }
    }

    private fun handleGoogleNoMatch() {
        failedTranscriptions++
        if (failedTranscriptions >= 2) {
            AppBus.log("Nic jsem nezachytila, končím dialog.")
            endDialog()
        } else {
            AppBus.log("Příkazu jsem nerozuměla.")
            speakInDialog("Nerozuměla jsem. Zopakuj to, prosím.")
        }
    }

    /** Zpracování zachyceného příkazu v dialogu (offline Vosk); běží na audio vlákně. */
    private fun handleCommandSegment(pcm: ShortArray): Boolean {
        AppBus.status.postValue("Rozumím ti…")
        val text = VoskTranscriber.transcribe(this, Dsp.trim(pcm))
        if (stopRequested) return true
        if (text.isBlank()) {
            handleEmptyCommand()
            return true
        }
        failedTranscriptions = 0
        AppBus.log("Ty: $text")
        processCommandText(text)
        return true
    }

    /** Nesrozumitelný / prázdný příkaz – jednou poprosí o zopakování, podruhé dialog ukončí. */
    private fun handleEmptyCommand() {
        failedTranscriptions++
        AppBus.log("Příkazu jsem nerozuměla ($failedTranscriptions×).")
        if (failedTranscriptions >= 2) {
            speakAndEnd("Nerozumím, zkus to prosím znovu od začátku.")
        } else {
            speakInDialog("Nerozuměla jsem. Zopakuj to, prosím.")
        }
    }

    /** Normalizace pro hlasové povely: malá písmena, bez interpunkce na konci. */
    private fun normalizeCmd(s: String): String =
        s.lowercase(Locale.forLanguageTag("cs")).replace(Regex("[.,!?…]+"), " ").replace(Regex("\\s+"), " ").trim()

    /** Pošle rozpoznaný text Kasandře a přečte odpověď. Blokující – volat mimo hlavní vlákno. */
    private fun processCommandText(rawText: String) {
        var text = rawText.trim()
        val norm = normalizeCmd(text)

        // "konec" = okamžitě ukončit dialog, nic se neposílá
        if (norm == "konec" || norm == "a konec") {
            AppBus.log("Povel „konec“ – dialog ukončen.")
            speakAndEnd("Dobře.")
            return
        }
        // "stop" na konci = utnout diktování; pošle se jen to, co zaznělo před ním
        if (norm == "stop") {
            AppBus.log("Povel „stop“ bez příkazu – dialog ukončen.")
            speakAndEnd("Dobře.")
            return
        }
        if (norm.endsWith(" stop")) {
            val words = text.trim().split(Regex("\\s+"))
            text = words.dropLast(1).joinToString(" ").trim().trimEnd('.', ',', '!', '?')
            AppBus.log("Povel „stop“ – posílám: $text")
            if (text.isBlank()) {
                speakAndEnd("Dobře.")
                return
            }
        }

        val composed = dialogContext?.let { "$it, $text" } ?: text
        val base = Prefs.baseUrl(this)
        if (base.isBlank()) {
            speakAndEnd("Nemám nastavenou adresu Kasandry. Vyplň ji prosím v aplikaci.")
            return
        }
        AppBus.status.postValue("Ptám se Kasandry…")
        val reply = try {
            KasandraApi.chat(base, composed)
        } catch (e: Exception) {
            AppBus.log("Chyba spojení s Kasandrou: ${e.message}")
            if (!stopRequested) speakAndEnd("Nepodařilo se mi spojit s Kasandrou.")
            return
        }
        if (stopRequested) return
        AppBus.log("Kasandra: " + reply.replace("\n", " ").take(300))
        dialogTurns++
        val isQuestion = reply.trimEnd().endsWith("?")
        if (isQuestion && dialogTurns < MAX_DIALOG_TURNS) {
            dialogContext = composed
            speakInDialog(shortenForTts(reply))
        } else {
            speakAndEnd(shortenForTts(reply))
        }
    }

    /** Řekne odpověď a nechá dialog běžet dál (čeká na další větu). */
    private fun speakInDialog(text: String) {
        endAfterSpeak = false
        commandDeadline = System.currentTimeMillis() + 60_000   // pojistka, unmute nastaví přesně
        if (!speak(text)) {
            if (dialogUsesGoogle) startGoogleListening()
            else commandDeadline = System.currentTimeMillis() + CMD_LISTEN_WINDOW_MS
        }
    }

    /** Řekne odpověď a dialog ukončí. */
    private fun speakAndEnd(text: String) {
        endAfterSpeak = true
        commandDeadline = Long.MAX_VALUE
        if (!speak(text)) {
            handler.post { endDialog() }
        }
    }

    private fun endDialog() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { endDialog() }
            return
        }
        handler.removeCallbacks(googleTimeout)
        googleListening = false
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {
        }
        micPaused = false
        endAfterSpeak = false
        dialogContext = null
        dialogTurns = 0
        if (mode == Mode.COMMAND) {
            mode = Mode.WAKE
            AppBus.status.postValue("Naslouchám na „kasandro“")
        }
        try {
            shortLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
    }

    /**
     * Upraví text odpovědi pro čtení nahlas: pryč odrážky, číslování, markdown značky
     * a symboly; řádky spojí do přirozeně plynoucích vět.
     */
    private fun shortenForTts(text: String): String {
        val lines = text.replace("\r", "").split("\n")
        val sb = StringBuilder()
        for (raw in lines) {
            var line = raw.trim()
            if (line.isEmpty()) continue
            // oddělovací čáry pryč
            if (Regex("^[-=_*]{3,}$").matches(line)) continue
            // odrážky a číslování na začátku řádku pryč
            line = line.replace(Regex("^(?:[-*•·–—>]+|\\d+[.)])\\s*"), "")
            // markdown značky a symboly, které TTS čte jako nesmysly
            line = line.replace(Regex("[*_#`|~\\[\\]]+"), " ")
            line = line.replace(Regex("[✔✖✅❌★☆→⇒•·]+"), " ")
            line = line.replace(Regex("\\s+"), " ").trim()
            if (line.isEmpty()) continue
            if (sb.isNotEmpty()) {
                val prev = sb.last()
                sb.append(if (prev == '.' || prev == '!' || prev == '?' || prev == ':') " " else ", ")
            }
            sb.append(line)
        }
        var flat = sb.toString().replace(Regex("\\s+"), " ").replace(Regex(",\\s*,"), ",").trim()
        if (flat.isEmpty()) flat = "Hotovo."
        return if (flat.length <= 600) flat else flat.take(600) + "… a tak dále."
    }

    private fun launchAssistant() {
        if (!Settings.canDrawOverlays(this)) {
            AppBus.log("Chybí povolení „zobrazení přes jiné aplikace“ – asistenta z pozadí nelze spustit.")
            speak("Asistenta se nepodařilo spustit.")
            return
        }
        val candidates = listOf(Intent(Intent.ACTION_VOICE_COMMAND), Intent(Intent.ACTION_ASSIST))
        for (i in candidates) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(packageManager) == null) continue
            try {
                startActivity(i)
                AppBus.log("Pokus o spuštění asistenta (${i.action}).")
                return
            } catch (e: Exception) {
                AppBus.log("Spuštění ${i.action} selhalo: ${e.javaClass.simpleName}")
            }
        }
        AppBus.log("Asistenta se nepodařilo spustit – zkus povolit „zobrazení přes jiné aplikace“.")
        speak("Asistenta se nepodařilo spustit.")
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                val res = t.setLanguage(Locale("cs", "CZ"))
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    AppBus.log("Čeština v TTS není dostupná – použiji výchozí hlas.")
                }
                t.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { unmute() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { unmute() }
                    }
                })
                ttsReady = true
            } else {
                AppBus.log("Hlasový výstup (TTS) se nepodařilo inicializovat.")
            }
        }
    }

    private val unmuteFallback = Runnable { unmute() }

    /** Přehraje hlášku. Vrací true, když se mluví (mikrofon je do dokončení ztlumený). */
    private fun speak(text: String): Boolean {
        val t = tts
        if (t == null || !ttsReady) {
            AppBus.log("TTS není připraveno – hláška: $text")
            return false
        }
        muted = true
        handler.removeCallbacks(unmuteFallback)
        handler.postDelayed(unmuteFallback, 10_000L + 150L * text.length)
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kasandra-wake")
        if (r != TextToSpeech.SUCCESS) {
            AppBus.log("TTS speak selhalo ($r).")
            unmute()
            return false
        }
        return true
    }

    private fun unmute() {
        handler.removeCallbacks(unmuteFallback)
        if (muted) {
            muted = false
            skipUntil = System.currentTimeMillis() + 500
            if (mode == Mode.COMMAND) {
                if (endAfterSpeak) {
                    endDialog()
                } else if (dialogUsesGoogle) {
                    startGoogleListening()
                } else {
                    commandDeadline = System.currentTimeMillis() + CMD_LISTEN_WINDOW_MS
                    AppBus.status.postValue("Poslouchám…")
                }
            }
        }
    }

    private fun vibrate(ms: Long) {
        try {
            val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Vibrator::class.java)
            }
            v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }
}

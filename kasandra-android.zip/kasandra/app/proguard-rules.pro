# Zatím žádná speciální pravidla (minifyEnabled = false).

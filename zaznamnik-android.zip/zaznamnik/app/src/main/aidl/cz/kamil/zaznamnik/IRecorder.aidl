package cz.kamil.zaznamnik;

interface IRecorder {
    /** Spustí nahrávání do předaného souboru. Vrací popis použitého zdroje, nebo text chyby začínající "CHYBA". */
    String start(in ParcelFileDescriptor fd) = 1;
    /** Ukončí nahrávání, vrací krátký souhrn. */
    String stop() = 2;
    boolean isRecording() = 3;
    /** Diagnostika – zkusí otevřít jednotlivé zdroje zvuku a vrátí přehled. */
    String probe() = 4;
    void destroy() = 16777114;
}

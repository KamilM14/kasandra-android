package cz.kamil.zaznamnik;

interface IRecorder {
    /** Spustí nahrávání do předaného souboru. Vrací popis použitého zdroje, nebo text chyby začínající "CHYBA". */
    String start(in ParcelFileDescriptor fd);
    /** Ukončí nahrávání, vrací krátký souhrn (počet bajtů, vzorkovací frekvence). */
    String stop();
    boolean isRecording();
    /** Diagnostika – zkusí otevřít jednotlivé zdroje zvuku a vrátí přehled. */
    String probe();
    void destroy() = 16777114;
}

package cz.kamil.zaznamnik.shell

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.ParcelFileDescriptor
import android.util.Log
import cz.kamil.zaznamnik.IRecorder
import java.io.FileOutputStream
import kotlin.system.exitProcess

/**
 * Běží v procesu Shizuku pod uživatelem shell (uid 2000), který jako jediný
 * na nerootnutém telefonu smí sáhnout na zvuk hovoru.
 */
class RecorderService() : IRecorder.Stub() {

    @Suppress("unused")
    constructor(context: Context) : this()

    companion object {
        private const val TAG = "ZaznamnikShell"
        private val SOURCES = listOf(
            "VOICE_CALL" to MediaRecorder.AudioSource.VOICE_CALL,
            "VOICE_DOWNLINK" to MediaRecorder.AudioSource.VOICE_DOWNLINK,
            "VOICE_COMMUNICATION" to MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            "VOICE_RECOGNITION" to MediaRecorder.AudioSource.VOICE_RECOGNITION,
            "MIC" to MediaRecorder.AudioSource.MIC
        )
        private val RATES = intArrayOf(16000, 8000, 48000, 44100)
    }

    @Volatile private var running = false
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private var out: FileOutputStream? = null
    private var pfd: ParcelFileDescriptor? = null
    private var usedRate = 0
    private var usedSource = ""
    @Volatile private var written = 0L
    @Volatile private var maxAmplitude = 0

    override fun isRecording(): Boolean = running

    override fun start(fd: ParcelFileDescriptor): String {
        if (running) return "CHYBA: nahrávání už běží"
        val prep = Workarounds.apply()
        Log.i(TAG, "workarounds: $prep")

        var rec: AudioRecord? = null
        var chosenSource = ""
        var chosenRate = 0
        val problems = StringBuilder()

        outer@ for ((name, source) in SOURCES) {
            for (rate in RATES) {
                val candidate = try {
                    createRecord(source, rate)
                } catch (t: Throwable) {
                    problems.append("$name/$rate: ${t.javaClass.simpleName} ${t.message}; ")
                    null
                }
                if (candidate != null) {
                    rec = candidate
                    chosenSource = name
                    chosenRate = rate
                    break@outer
                }
            }
        }

        if (rec == null) {
            try { fd.close() } catch (_: Throwable) {}
            return "CHYBA: žádný zdroj zvuku nešel otevřít. $problems"
        }

        return try {
            pfd = fd
            out = FileOutputStream(fd.fileDescriptor)
            writeWavHeader(out!!, chosenRate, 0)
            record = rec
            usedRate = chosenRate
            usedSource = chosenSource
            written = 0
            maxAmplitude = 0
            running = true
            thread = Thread { pump() }.also { it.start() }
            "$chosenSource @ ${chosenRate}Hz | $prep"
        } catch (t: Throwable) {
            running = false
            try { rec.release() } catch (_: Throwable) {}
            try { fd.close() } catch (_: Throwable) {}
            "CHYBA: $t"
        }
    }

    override fun stop(): String {
        if (!running) return "nenahrávalo se"
        running = false
        try { thread?.join(2000) } catch (_: Throwable) {}
        thread = null
        try { record?.stop() } catch (_: Throwable) {}
        try { record?.release() } catch (_: Throwable) {}
        record = null
        val bytes = written
        try {
            out?.let { stream ->
                stream.flush()
                // dopsat správnou hlavičku WAV
                val channel = stream.channel
                channel.position(0)
                val header = wavHeader(usedRate, bytes)
                channel.write(java.nio.ByteBuffer.wrap(header))
                channel.force(false)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "hlavička: $t")
        }
        try { out?.close() } catch (_: Throwable) {}
        out = null
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        val seconds = if (usedRate > 0) bytes / (usedRate * 2.0) else 0.0
        return "$usedSource, %.1f s, %d kB, max hlasitost %d".format(seconds, bytes / 1024, maxAmplitude)
    }

    override fun probe(): String {
        val prep = Workarounds.apply()
        val sb = StringBuilder("prostředí: $prep\n")
        for ((name, source) in SOURCES) {
            var ok = false
            var detail = ""
            for (rate in RATES) {
                try {
                    val r = createRecord(source, rate)
                    if (r != null) {
                        ok = true
                        detail = "${rate}Hz"
                        r.stop()
                        r.release()
                        break
                    }
                } catch (t: Throwable) {
                    detail = t.message ?: t.javaClass.simpleName
                }
            }
            sb.append(if (ok) "OK   " else "ne   ").append(name).append("  ").append(detail).append('\n')
        }
        return sb.toString()
    }

    override fun destroy() {
        try { stop() } catch (_: Throwable) {}
        exitProcess(0)
    }

    /** Vytvoří a rozjede AudioRecord; vrátí null, když zdroj nejde použít. */
    private fun createRecord(source: Int, rate: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null

        val builder = AudioRecord.Builder()
        try {
            val setContext = AudioRecord.Builder::class.java.getMethod("setContext", Context::class.java)
            setContext.invoke(builder, FakeContext.get())
        } catch (t: Throwable) {
            Log.w(TAG, "setContext nešel: ${t.message}")
        }
        builder.setAudioSource(source)
        builder.setAudioFormat(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
        )
        builder.setBufferSizeInBytes(min * 8)

        val rec = builder.build()
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return null
        }
        rec.startRecording()
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            rec.release()
            return null
        }
        // ověřit, že opravdu tečou data
        val probe = ShortArray(256)
        var got = 0
        val deadline = System.currentTimeMillis() + 800
        while (System.currentTimeMillis() < deadline) {
            val n = rec.read(probe, 0, probe.size)
            if (n > 0) { got = n; break }
            if (n < 0) break
            Thread.sleep(20)
        }
        if (got <= 0) {
            try { rec.stop() } catch (_: Throwable) {}
            rec.release()
            return null
        }
        return rec
    }

    private fun pump() {
        val rec = record ?: return
        val stream = out ?: return
        val buf = ShortArray(2048)
        val bytes = ByteArray(buf.size * 2)
        while (running) {
            val n = try { rec.read(buf, 0, buf.size) } catch (t: Throwable) { -1 }
            if (n <= 0) {
                if (n < 0) break
                continue
            }
            var j = 0
            var localMax = maxAmplitude
            for (i in 0 until n) {
                val s = buf[i].toInt()
                val a = if (s < 0) -s else s
                if (a > localMax) localMax = a
                bytes[j++] = (s and 0xFF).toByte()
                bytes[j++] = ((s shr 8) and 0xFF).toByte()
            }
            maxAmplitude = localMax
            try {
                stream.write(bytes, 0, n * 2)
                written += n * 2
            } catch (t: Throwable) {
                Log.w(TAG, "zápis selhal: $t")
                break
            }
        }
    }

    private fun writeWavHeader(stream: FileOutputStream, rate: Int, dataBytes: Long) {
        stream.write(wavHeader(rate, dataBytes))
    }

    private fun wavHeader(rate: Int, dataBytes: Long): ByteArray {
        val header = ByteArray(44)
        val byteRate = rate * 2
        val totalLen = dataBytes + 36
        fun put(offset: Int, s: String) { for (i in s.indices) header[offset + i] = s[i].code.toByte() }
        fun putInt(offset: Int, v: Long) {
            header[offset] = (v and 0xFF).toByte()
            header[offset + 1] = ((v shr 8) and 0xFF).toByte()
            header[offset + 2] = ((v shr 16) and 0xFF).toByte()
            header[offset + 3] = ((v shr 24) and 0xFF).toByte()
        }
        fun putShort(offset: Int, v: Int) {
            header[offset] = (v and 0xFF).toByte()
            header[offset + 1] = ((v shr 8) and 0xFF).toByte()
        }
        put(0, "RIFF"); putInt(4, totalLen); put(8, "WAVE"); put(12, "fmt ")
        putInt(16, 16); putShort(20, 1); putShort(22, 1)
        putInt(24, rate.toLong()); putInt(28, byteRate.toLong())
        putShort(32, 2); putShort(34, 16)
        put(36, "data"); putInt(40, dataBytes)
        return header
    }
}

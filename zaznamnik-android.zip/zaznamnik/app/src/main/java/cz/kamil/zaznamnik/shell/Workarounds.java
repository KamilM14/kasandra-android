package cz.kamil.zaznamnik.shell;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Looper;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Podvrhne procesu Shizuku user service prostředí aplikace, aby šlo vytvořit
 * AudioRecord se zdrojem VOICE_CALL. Převzato z projektu scrcpy (Apache 2.0).
 */
public final class Workarounds {

    private static Class<?> activityThreadClass;
    private static Object activityThread;
    private static boolean applied;

    private Workarounds() {
    }

    public static synchronized String apply() {
        if (applied) {
            return "prostředí už připraveno";
        }
        StringBuilder log = new StringBuilder();
        try {
            if (Looper.myLooper() == null && Looper.getMainLooper() == null) {
                Looper.prepareMainLooper();
            }
        } catch (Throwable t) {
            log.append("looper: ").append(t.getMessage()).append("; ");
        }
        try {
            activityThreadClass = Class.forName("android.app.ActivityThread");
            Constructor<?> c = activityThreadClass.getDeclaredConstructor();
            c.setAccessible(true);
            activityThread = c.newInstance();

            Field sCurrent = activityThreadClass.getDeclaredField("sCurrentActivityThread");
            sCurrent.setAccessible(true);
            sCurrent.set(null, activityThread);

            Field systemThread = activityThreadClass.getDeclaredField("mSystemThread");
            systemThread.setAccessible(true);
            systemThread.setBoolean(activityThread, true);
        } catch (Throwable t) {
            log.append("activityThread: ").append(t).append("; ");
            return log.toString();
        }

        if (Build.VERSION.SDK_INT >= 31) {
            fillConfigurationController(log);
        }
        fillAppInfo(log);
        fillAppContext(log);
        applied = true;
        return log.length() == 0 ? "prostředí připraveno" : log.toString();
    }

    private static void fillAppInfo(StringBuilder log) {
        try {
            Class<?> appBindDataClass = Class.forName("android.app.ActivityThread$AppBindData");
            Constructor<?> ctor = appBindDataClass.getDeclaredConstructor();
            ctor.setAccessible(true);
            Object appBindData = ctor.newInstance();

            ApplicationInfo applicationInfo = new ApplicationInfo();
            applicationInfo.packageName = FakeContext.PACKAGE_NAME;

            Field appInfoField = appBindDataClass.getDeclaredField("appInfo");
            appInfoField.setAccessible(true);
            appInfoField.set(appBindData, applicationInfo);

            Field mBoundApplication = activityThreadClass.getDeclaredField("mBoundApplication");
            mBoundApplication.setAccessible(true);
            mBoundApplication.set(activityThread, appBindData);
        } catch (Throwable t) {
            log.append("appInfo: ").append(t.getMessage()).append("; ");
        }
    }

    private static void fillAppContext(StringBuilder log) {
        try {
            Application app = Instrumentation.newApplication(Application.class, FakeContext.get());
            Field mInitialApplication = activityThreadClass.getDeclaredField("mInitialApplication");
            mInitialApplication.setAccessible(true);
            mInitialApplication.set(activityThread, app);
        } catch (Throwable t) {
            log.append("appContext: ").append(t.getMessage()).append("; ");
        }
    }

    private static void fillConfigurationController(StringBuilder log) {
        try {
            Class<?> configurationControllerClass = Class.forName("android.app.ConfigurationController");
            Class<?> activityThreadInternalClass = Class.forName("android.app.ActivityThreadInternal");
            Constructor<?> ctor = configurationControllerClass.getDeclaredConstructor(activityThreadInternalClass);
            ctor.setAccessible(true);
            Object configurationController = ctor.newInstance(activityThread);
            Field field = activityThreadClass.getDeclaredField("mConfigurationController");
            field.setAccessible(true);
            field.set(activityThread, configurationController);
        } catch (Throwable t) {
            log.append("configController: ").append(t.getMessage()).append("; ");
        }
    }

    public static Context getSystemContext() {
        try {
            if (activityThread == null) {
                apply();
            }
            Method m = activityThreadClass.getDeclaredMethod("getSystemContext");
            m.setAccessible(true);
            return (Context) m.invoke(activityThread);
        } catch (Throwable t) {
            return null;
        }
    }
}

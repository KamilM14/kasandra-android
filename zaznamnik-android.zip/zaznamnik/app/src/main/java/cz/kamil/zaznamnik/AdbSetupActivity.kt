package cz.kamil.zaznamnik

import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Nastavení vestavěného ADB – spárování s bezdrátovým laděním přímo v aplikaci.
 */
class AdbSetupActivity : AppCompatActivity() {

    private lateinit var stav: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Vestavěné ADB (bez Shizuku)"

        val obal = LinearLayout(this)
        obal.orientation = LinearLayout.VERTICAL
        obal.setPadding(48, 40, 48, 40)

        stav = TextView(this)
        stav.textSize = 14f
        obal.addView(stav)

        val navod = TextView(this)
        navod.textSize = 14f
        navod.setLineSpacing(6f, 1f)
        navod.setPadding(0, 24, 0, 24)
        navod.text = if (Build.VERSION.SDK_INT >= 30) NAVOD else
            "Vestavěné ADB potřebuje Android 11 nebo novější. Na tomto telefonu použij Shizuku."
        obal.addView(navod)

        val portParovani = EditText(this)
        portParovani.hint = "Port párování (např. 37123)"
        portParovani.inputType = InputType.TYPE_CLASS_NUMBER
        obal.addView(portParovani)

        val kod = EditText(this)
        kod.hint = "6místný párovací kód"
        kod.inputType = InputType.TYPE_CLASS_NUMBER
        obal.addView(kod)

        val btnParovat = Button(this)
        btnParovat.text = "1) Spárovat"
        btnParovat.setOnClickListener {
            val port = portParovani.text.toString().trim().toIntOrNull()
            val k = kod.text.toString().trim()
            if (port == null || k.length < 6) {
                Toast.makeText(this, "Vyplň port párování a 6místný kód", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            stav.text = "Páruji…"
            AdbRecorder.parovat(this, port, k) { ok, zprava ->
                runOnUiThread {
                    stav.text = zprava
                    if (ok) Toast.makeText(this, "Spárováno", Toast.LENGTH_SHORT).show()
                    obnovit()
                }
            }
        }
        obal.addView(btnParovat)

        val portPripojeni = EditText(this)
        portPripojeni.hint = "Port připojení (nepovinné – zkusí se i automaticky)"
        portPripojeni.inputType = InputType.TYPE_CLASS_NUMBER
        obal.addView(portPripojeni)

        val btnPripojit = Button(this)
        btnPripojit.text = "2) Připojit"
        btnPripojit.setOnClickListener {
            val port = portPripojeni.text.toString().trim().toIntOrNull()
            stav.text = "Připojuji…"
            AdbRecorder.pripojit(this, port) { ok, zprava ->
                runOnUiThread {
                    stav.text = zprava
                    if (ok) {
                        Toast.makeText(this, "Připojeno", Toast.LENGTH_SHORT).show()
                        CallService.zajistitBeh(this)
                    }
                    obnovit()
                }
            }
        }
        obal.addView(btnPripojit)

        val scroll = ScrollView(this)
        scroll.addView(obal)
        setContentView(scroll)
        obnovit()
    }

    override fun onResume() {
        super.onResume()
        obnovit()
    }

    private fun obnovit() {
        val d = AdbRecorder.detail()
        stav.text = AdbRecorder.stav(this) + if (d.isBlank()) "" else "\n$d"
    }

    companion object {
        private val NAVOD = """
Vestavěné ADB znamená, že se aplikace sama napojí na bezdrátové ladění tvého
telefonu a nepotřebuje Shizuku ani počítač. Nastavuje se jednou:

1. Nastavení → O telefonu → 7× klepnout na verzi systému
   (odemkne Možnosti pro vývojáře).
2. Telefon připoj na Wi-Fi (na mobilních datech to nejde).
3. Nastavení → Další nastavení → Pro vývojáře → zapnout Bezdrátové ladění.
4. Ťukni na "Párování zařízení pomocí párovacího kódu".
   Ukáže se 6místný kód a adresa s portem, třeba 192.168.0.5:37123.
   Číslo za dvojtečkou je PORT PÁROVÁNÍ.
5. Sem zadej port párování a kód a dej "Spárovat".
6. Vrať se na obrazovku Bezdrátové ladění – nahoře je "IP adresa a port"
   s JINÝM portem. To je PORT PŘIPOJENÍ. Můžeš ho zadat, nebo nechat prázdné
   a dát jen "Připojit" (aplikace ho zkusí najít sama).

Po restartu telefonu stačí znovu zapnout Bezdrátové ladění a v Záznamníku
dát "Připojit" – párování už se opakovat nemusí.
""".trimIndent()
    }
}

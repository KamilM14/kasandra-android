package cz.kamil.zaznamnik.shell

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.FileDescriptor
import java.io.FileOutputStream
import kotlin.system.exitProcess

/**
 * Samostatný nahrávací proces spouštěný přes ADB pod uživatelem shell:
 *   CLASSPATH=<apk> app_process /system/bin cz.kamil.zaznamnik.shell.Daemon
 *
 * Na standardní výstup zapíše nejdřív hlavičku "ZAZN1 <zdroj> <rate>\n"
 * a pak surové PCM 16bit mono. Nahrává, dokud ho aplikace nezavře
 * (stdin dostane EOF) nebo dokud ho systém neukončí na konci hovoru.
 * Logy jdou na standardní chybový výstup.
 */
object Daemon {

    private val SOURCES = listOf(
        "VOICE_CALL" to MediaRecorder.AudioSource.VOICE_CALL,
        "VOICE_DOWNLINK" to MediaRecorder.AudioSource.VOICE_DOWNLINK,
        "VOICE_COMMUNICATION" to MediaRecorder.AudioSource.VOICE_COMMUNICATION,
        "VOICE_RECOGNITION" to MediaRecorder.AudioSource.VOICE_RECOGNITION,
        "MIC" to MediaRecorder.AudioSource.MIC
    )
    private val RATES = intArrayOf(16000, 8000, 48000, 44100)

    @Volatile private var running = true

    @JvmStatic
    fun main(args: Array<String>) {
        val out = FileOutputStream(FileDescriptor.out)
        try {
            Workarounds.apply()
        } catch (t: Throwable) {
            System.err.println("prostředí: ${t.message}")
        }

        var rec: AudioRecord? = null
        var chosenSource = ""
        var chosenRate = 0
        outer@ for ((name, source) in SOURCES) {
            for (rate in RATES) {
                val candidate = try {
                    createRecord(source, rate)
                } catch (t: Throwable) {
                    System.err.println("$name/$rate: ${t.javaClass.simpleName} ${t.message}")
                    null
                }
                if (candidate != null) {
                    rec = candidate; chosenSource = name; chosenRate = rate; break@outer
                }
            }
        }

        if (rec == null) {
            System.err.println("CHYBA: žádný zdroj zvuku nešel otevřít")
            out.write("ZAZN1 NONE 0\n".toByteArray())
            out.flush()
            exitProcess(2)
        }

        // Hlavička pro aplikaci
        out.write("ZAZN1 $chosenSource $chosenRate\n".toByteArray())
        out.flush()
        System.err.println("nahrávám $chosenSource @ ${chosenRate}Hz")

        // Kdyby aplikace zavřela spojení, ukončit se.
        Thread {
            try {
                while (System.`in`.read() != -1) { /* čekáme na EOF */ }
            } catch (_: Throwable) {
            }
            running = false
        }.apply { isDaemon = true; start() }

        val buf = ShortArray(2048)
        val bytes = ByteArray(buf.size * 2)
        try {
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) { if (n < 0) break else continue }
                var j = 0
                for (i in 0 until n) {
                    val s = buf[i].toInt()
                    bytes[j++] = (s and 0xFF).toByte()
                    bytes[j++] = ((s shr 8) and 0xFF).toByte()
                }
                out.write(bytes, 0, n * 2)
            }
            out.flush()
        } catch (t: Throwable) {
            System.err.println("konec zápisu: ${t.message}")
        } finally {
            try { rec.stop() } catch (_: Throwable) {}
            try { rec.release() } catch (_: Throwable) {}
        }
        exitProcess(0)
    }

    private fun createRecord(source: Int, rate: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val builder = AudioRecord.Builder()
        try {
            val setContext = AudioRecord.Builder::class.java.getMethod("setContext", android.content.Context::class.java)
            setContext.invoke(builder, FakeContext.get())
        } catch (t: Throwable) {
            System.err.println("setContext: ${t.message}")
        }
        builder.setAudioSource(source)
        builder.setAudioFormat(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
        )
        builder.setBufferSizeInBytes(min * 8)
        val rec = builder.build()
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        rec.startRecording()
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) { rec.release(); return null }
        val probe = ShortArray(256)
        var got = 0
        val deadline = System.currentTimeMillis() + 800
        while (System.currentTimeMillis() < deadline) {
            val r = rec.read(probe, 0, probe.size)
            if (r > 0) { got = r; break }
            if (r < 0) break
            Thread.sleep(20)
        }
        if (got <= 0) { try { rec.stop() } catch (_: Throwable) {}; rec.release(); return null }
        return rec
    }
}

package cz.kamil.zaznamnik

import android.content.Context
import android.util.Log
import io.github.muntashirakon.adb.AdbStream
import java.util.concurrent.Executors

/**
 * Nahrávání přes vlastní ADB spojení aplikace (bez Shizuku).
 * Aplikace se jednou spáruje s bezdrátovým laděním a pak si sama spouští
 * nahrávací proces přes ADB příkaz app_process.
 */
object AdbRecorder {

    private const val TAG = "Zaznamnik"
    private const val PREFS = "zaznamnik_adb"
    private const val HOST = "127.0.0.1"

    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var pripojeno = false
    @Volatile private var posledniChyba = ""

    fun jePripojeno(): Boolean = pripojeno

    fun bylSparovan(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("paired", false)

    fun stav(ctx: Context): String = when {
        pripojeno -> "ADB připojeno"
        bylSparovan(ctx) -> "ADB spárováno (nepřipojeno – zapni bezdrátové ladění)"
        else -> "ADB nenastaveno"
    }

    fun detail(): String = if (posledniChyba.isBlank()) "" else "ADB: $posledniChyba"

    /** Spárování: běží na pozadí, callback dostane hlášku pro uživatele. */
    fun parovat(ctx: Context, port: Int, kod: String, callback: (Boolean, String) -> Unit) {
        io.execute {
            try {
                val ok = AdbManager.get(ctx).pair(HOST, port, kod)
                if (ok) {
                    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putBoolean("paired", true).apply()
                    callback(true, "Spárováno. Teď dej Připojit.")
                } else {
                    callback(false, "Párování se nepovedlo.")
                }
            } catch (t: Throwable) {
                Log.w(TAG, "pair", t)
                callback(false, "Párování selhalo: ${t.message}")
            }
        }
    }

    /** Připojení: nejdřív automaticky přes mDNS, případně přes zadaný port. */
    fun pripojit(ctx: Context, port: Int?, callback: (Boolean, String) -> Unit) {
        io.execute {
            val ok = pripojitBlokujici(ctx, port)
            callback(ok, if (ok) "Připojeno." else "Připojení selhalo: $posledniChyba")
        }
    }

    private fun pripojitBlokujici(ctx: Context, port: Int?): Boolean {
        val m = AdbManager.get(ctx)
        try {
            if (m.isConnected) { pripojeno = true; return true }
        } catch (_: Throwable) {}
        m.setTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        // 1) zadaný port
        if (port != null && port in 1..65535) {
            try {
                if (m.connect(HOST, port)) {
                    pripojeno = true
                    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putInt("port", port).apply()
                    return true
                }
            } catch (t: Throwable) {
                posledniChyba = t.message ?: t.javaClass.simpleName
                Log.w(TAG, "connect(port)", t)
            }
        }
        // 2) automatické hledání přes mDNS (port se po restartu mění)
        try {
            if (m.autoConnect(ctx.applicationContext, 8000)) {
                pripojeno = true
                return true
            }
        } catch (t: Throwable) {
            posledniChyba = t.message ?: t.javaClass.simpleName
            Log.w(TAG, "autoConnect", t)
        }
        pripojeno = false
        return false
    }

    /** Zajistí spojení (volá se z pracovního vlákna při hovoru). */
    fun zajistitSpojeni(ctx: Context): Boolean {
        if (pripojeno) {
            try { if (AdbManager.get(ctx).isConnected) return true } catch (_: Throwable) {}
        }
        if (!bylSparovan(ctx)) return false
        val ulozenyPort = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("port", -1)
        return pripojitBlokujici(ctx, if (ulozenyPort > 0) ulozenyPort else null)
    }

    /**
     * Otevře nahrávací proud přes ADB. Vrací AdbStream (input = PCM se hlavičkou),
     * nebo null když se to nepovede. Volat z pracovního vlákna.
     */
    fun otevritNahravani(ctx: Context): AdbStream? {
        return try {
            val apk = ctx.applicationInfo.sourceDir
            val prikaz = "exec:CLASSPATH=$apk /system/bin/app_process /system/bin " +
                "--nice-name=zaznamnik_rec cz.kamil.zaznamnik.shell.Daemon"
            AdbManager.get(ctx).openStream(prikaz)
        } catch (t: Throwable) {
            posledniChyba = t.message ?: t.javaClass.simpleName
            Log.w(TAG, "otevritNahravani", t)
            null
        }
    }

    fun odpojit(ctx: Context) {
        io.execute {
            try { AdbManager.get(ctx).disconnect() } catch (_: Throwable) {}
            pripojeno = false
        }
    }
}

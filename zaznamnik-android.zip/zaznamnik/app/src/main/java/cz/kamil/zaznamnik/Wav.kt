package cz.kamil.zaznamnik

import java.io.RandomAccessFile

/** Pomůcka pro zápis WAV souboru (16bit mono PCM). */
object Wav {

    fun hlavicka(rate: Int, dataBytes: Long): ByteArray {
        val header = ByteArray(44)
        val byteRate = rate * 2
        val totalLen = dataBytes + 36
        fun put(off: Int, s: String) { for (i in s.indices) header[off + i] = s[i].code.toByte() }
        fun putInt(off: Int, v: Long) {
            header[off] = (v and 0xFF).toByte()
            header[off + 1] = ((v shr 8) and 0xFF).toByte()
            header[off + 2] = ((v shr 16) and 0xFF).toByte()
            header[off + 3] = ((v shr 24) and 0xFF).toByte()
        }
        fun putShort(off: Int, v: Int) {
            header[off] = (v and 0xFF).toByte()
            header[off + 1] = ((v shr 8) and 0xFF).toByte()
        }
        put(0, "RIFF"); putInt(4, totalLen); put(8, "WAVE"); put(12, "fmt ")
        putInt(16, 16); putShort(20, 1); putShort(22, 1)
        putInt(24, rate.toLong()); putInt(28, byteRate.toLong())
        putShort(32, 2); putShort(34, 16)
        put(36, "data"); putInt(40, dataBytes)
        return header
    }

    /** Dopíše správnou hlavičku na začátek hotového souboru. */
    fun dokoncit(path: String, rate: Int, dataBytes: Long) {
        RandomAccessFile(path, "rw").use { raf ->
            raf.seek(0)
            raf.write(hlavicka(rate, dataBytes))
        }
    }
}

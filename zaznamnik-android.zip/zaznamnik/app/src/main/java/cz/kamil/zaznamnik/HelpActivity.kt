package cz.kamil.zaznamnik

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Návod, jak aplikaci rozchodit na novém telefonu. */
class HelpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Návod k nastavení"

        val obal = LinearLayout(this)
        obal.orientation = LinearLayout.VERTICAL
        obal.setPadding(48, 48, 48, 48)

        val text = TextView(this)
        text.textSize = 15f
        text.setLineSpacing(6f, 1.0f)
        text.setTextIsSelectable(true)
        text.text = NAVOD
        obal.addView(text)

        val sdilet = Button(this)
        sdilet.text = "Poslat návod jinam"
        sdilet.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_SUBJECT, "Záznamník – návod k nastavení")
            i.putExtra(Intent.EXTRA_TEXT, NAVOD)
            startActivity(Intent.createChooser(i, "Poslat návod"))
        }
        obal.addView(sdilet)

        val scroll = ScrollView(this)
        scroll.addView(obal)
        setContentView(scroll)
    }

    companion object {
        val NAVOD = """
JAK ZÁZNAMNÍK FUNGUJE

Od Androidu 10 běžná aplikace na zvuk hovoru nesmí. Záznamník proto používá
Shizuku: to je pomocník, který aplikaci půjčí oprávnění uživatele "shell"
(stejná úroveň, jakou má počítač připojený přes ladění USB). Teprve s ním jde
nahrát obě strany hovoru. Root není potřeba.

Když Shizuku neběží, Záznamník nahrává aspoň z mikrofonu — pak je ale druhá
strana slyšet jen při zapnutém hlasitém odposlechu.


KROK 1 — NAINSTALOVAT SHIZUKU

Obchod Play → hledej "Shizuku" (autor RikkaW) → nainstalovat.


KROK 2 — SPUSTIT SLUŽBU SHIZUKU

Musí se udělat po každém restartu telefonu. Dvě cesty:

A) Bezdrátové ladění (bez počítače)
   1. Telefon musí být na Wi-Fi (na mobilních datech to nejde).
   2. Nastavení → O telefonu → 7× klepnout na verzi systému.
   3. Nastavení → Další nastavení → Pro vývojáře → zapnout Ladění USB
      a Bezdrátové ladění.
   4. V aplikaci Shizuku zvolit "Spustit přes bezdrátové ladění"
      a projít průvodce (spárování kódem).

B) Přes počítač a USB kabel (spolehlivější)
   1. Na telefonu zapnout Ladění USB (viz body 2–3 výše).
   2. Na počítači mít nástroje ADB (platform-tools od Google).
   3. Telefon připojit kabelem, potvrdit dialog "Povolit ladění USB".
   4. Spustit příkaz:
      adb shell sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh


KROK 3 — POVOLIT ZÁZNAMNÍKU, CO POTŘEBUJE

1. Nastavení → Aplikace → Záznamník → Oprávnění:
   povolit Telefon, Mikrofon a Oznámení.
   (Bez oprávnění Telefon aplikace nepozná, že hovor začal.)
2. Otevřít Záznamník → tlačítko "Povolit Shizuku" → v dialogu Povolit.
3. Nahoře má být "Shizuku: připraveno" a "povolení: uděleno".


KROK 4 — OVĚŘIT ZDROJE ZVUKU

Tlačítko "Diagnostika" vypíše, které zdroje zvuku telefon pustí.
Nejlepší je "OK VOICE_CALL" — pak se nahrávají obě strany v plné kvalitě.
Když je VOICE_CALL "ne", aplikace použije první další zdroj, který funguje.


KROK 5 — ABY TO VYDRŽELO BĚŽET

Na telefonech Xiaomi (MIUI/HyperOS) systém rád zabíjí procesy na pozadí.
Pro Shizuku i pro Záznamník nastav:
  Nastavení → Aplikace → Správa aplikací → (aplikace) →
    Spořič baterie → Bez omezení
    Automatické spouštění → zapnout
A v přehledu spuštěných aplikací obě zamknout (tažením dolů na kartě).

Kdyby se Shizuku i tak pořád vypínalo, pomůže vypnout optimalizaci MIUI:
Pro vývojáře → Zapnout optimalizaci MIUI → vypnout. Když tam ta položka není,
dole na téže stránce je "Obnovit výchozí hodnoty" — po něm se objeví
(pozor, reset vypne i ladění USB, bude se muset znovu zapnout).


BĚŽNÝ PROVOZ

- V liště je trvalé oznámení "Hlídám hovory" — bez něj by službu systém zabil.
- Nahrávání se spustí samo při vyzvednutí hovoru a skončí s hovorem.
- Archiv drží posledních 5 nahrávek, starší se mažou.
- Tlačítko "Ponechat" (★) nahrávku z mazání vyjme, "Název" jí dá vlastní jméno.
- Když Shizuku zhasne, aplikace to pozná a upozorní oznámením.


PRÁVNÍ POZNÁMKA

Nahrávat vlastní hovor pro svou potřebu je v ČR přípustné hlavně kvůli ochraně
vlastních práv. Zveřejnění nebo předání nahrávky dál je věc jiná a vztahuje se
na to i GDPR. Bezpečnější je druhou stranu o nahrávání informovat.
""".trimIndent()
    }
}

package cz.kamil.zaznamnik

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Archiv nahrávek: drží posledních LIMIT dočasných záznamů, starší maže.
 * Nahrávka označená "ponechat" se do limitu nepočítá a nikdy se nesmaže sama.
 */
object RecordStore {

    const val LIMIT = 5
    private const val PREFS = "zaznamnik"
    private const val KEY = "nahravky"

    data class Item(
        val file: String,
        val startedAt: Long,
        var number: String,
        var keep: Boolean,
        var note: String,
        var name: String = ""
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "nahravky").apply { mkdirs() }

    fun newFile(ctx: Context, ext: String): File =
        File(dir(ctx), "hovor-${System.currentTimeMillis()}.$ext")

    fun list(ctx: Context): MutableList<Item> {
        val raw = prefs(ctx).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (t: Throwable) { JSONArray() }
        val out = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val item = Item(
                o.optString("file"),
                o.optLong("startedAt"),
                o.optString("number"),
                o.optBoolean("keep"),
                o.optString("note"),
                o.optString("name")
            )
            if (File(item.file).exists()) out.add(item)
        }
        out.sortByDescending { it.startedAt }
        return out
    }

    fun save(ctx: Context, items: List<Item>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("file", it.file)
                    .put("startedAt", it.startedAt)
                    .put("number", it.number)
                    .put("keep", it.keep)
                    .put("note", it.note)
                    .put("name", it.name)
            )
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun add(ctx: Context, file: File, number: String, note: String) {
        val items = list(ctx)
        items.add(0, Item(file.absolutePath, System.currentTimeMillis(), number, false, note, ""))
        save(ctx, items)
        prune(ctx)
    }

    fun setName(ctx: Context, path: String, name: String) {
        val items = list(ctx)
        items.firstOrNull { it.file == path }?.name = name.trim()
        save(ctx, items)
    }

    fun setKeep(ctx: Context, path: String, keep: Boolean) {
        val items = list(ctx)
        items.firstOrNull { it.file == path }?.keep = keep
        save(ctx, items)
        prune(ctx)
    }

    fun delete(ctx: Context, path: String) {
        val items = list(ctx)
        items.removeAll { it.file == path }
        File(path).delete()
        save(ctx, items)
    }

    /** Smaže nejstarší neoznačené nahrávky nad limit. */
    fun prune(ctx: Context) {
        val items = list(ctx)
        val temp = items.filter { !it.keep }.sortedByDescending { it.startedAt }
        if (temp.size <= LIMIT) return
        val toDrop = temp.drop(LIMIT)
        toDrop.forEach { File(it.file).delete() }
        val kept = items.filter { item -> toDrop.none { it.file == item.file } }
        save(ctx, kept)
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}

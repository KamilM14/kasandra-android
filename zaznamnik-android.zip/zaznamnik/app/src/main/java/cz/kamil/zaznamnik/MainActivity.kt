package cz.kamil.zaznamnik

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import rikka.shizuku.Shizuku
import java.io.File
import java.util.Date

class MainActivity : AppCompatActivity() {

    private lateinit var stav: TextView
    private lateinit var seznam: LinearLayout

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { obnovit() } }
    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread {
            obnovit()
            // Jakmile se spojení se Shizuku objeví, rovnou si řekneme o povolení.
            if (ShizukuRecorder.shizukuAvailable() && !ShizukuRecorder.hasPermission()) {
                try { Shizuku.requestPermission(ShizukuRecorder.PERMISSION_CODE) } catch (_: Throwable) {}
            }
        }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener { runOnUiThread { obnovit() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        stav = findViewById(R.id.stav)
        seznam = findViewById(R.id.seznam)

        findViewById<Button>(R.id.btnShizuku).setOnClickListener { povolitShizuku() }
        findViewById<Button>(R.id.btnDiagnostika).setOnClickListener { diagnostika() }
        findViewById<Button>(R.id.btnSluzba).setOnClickListener {
            CallService.zajistitBeh(this)
            Toast.makeText(this, "Hlídání spuštěno", Toast.LENGTH_SHORT).show()
            stav.postDelayed({ obnovit() }, 500)
        }

        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
        try { Shizuku.addBinderReceivedListenerSticky(binderListener) } catch (_: Throwable) {}
        try { Shizuku.addBinderDeadListener(binderDeadListener) } catch (_: Throwable) {}
        pozadatOOpravneni()
        CallService.zajistitBeh(this)
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
        try { Shizuku.removeBinderReceivedListener(binderListener) } catch (_: Throwable) {}
        try { Shizuku.removeBinderDeadListener(binderDeadListener) } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        obnovit()
    }

    private fun pozadatOOpravneni() {
        val chybi = mutableListOf<String>()
        val potreba = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            potreba.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        potreba.forEach {
            if (ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED) chybi.add(it)
        }
        if (chybi.isNotEmpty()) ActivityCompat.requestPermissions(this, chybi.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        CallService.zajistitBeh(this)
        obnovit()
    }

    private fun povolitShizuku() {
        if (!ShizukuRecorder.shizukuAvailable()) {
            AlertDialog.Builder(this)
                .setTitle("Aplikace k Shizuku nedosáhne")
                .setMessage(
                    "Shizuku sice může běžet, ale tahle aplikace k němu nemá spojení.\n\n" +
                        ShizukuRecorder.detail() +
                        "\n\nZkus: v aplikaci Shizuku otevřít seznam aplikací, nebo Záznamník úplně zavřít a spustit znovu."
                )
                .setPositiveButton("Rozumím", null)
                .show()
            return
        }
        if (ShizukuRecorder.hasPermission()) {
            Toast.makeText(this, "Povolení už je uděleno", Toast.LENGTH_SHORT).show()
            obnovit()
            return
        }
        try { Shizuku.requestPermission(ShizukuRecorder.PERMISSION_CODE) } catch (t: Throwable) {
            Toast.makeText(this, "Nešlo požádat: $t", Toast.LENGTH_LONG).show()
        }
    }

    private fun diagnostika() {
        stav.text = "Zkouším zdroje zvuku…"
        ShizukuRecorder.probe { vysledek ->
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("Zdroje zvuku")
                    .setMessage(vysledek)
                    .setPositiveButton("Zavřít", null)
                    .show()
                obnovit()
            }
        }
    }

    private fun obnovit() {
        val radky = mutableListOf<String>()
        radky.add("Shizuku: " + ShizukuRecorder.stav())
        radky.add("Stav: " + if (CallService.nahrava) "nahrávám hovor" else "čekám na hovor")
        radky.add("Poslední nahrávání: " + CallService.posledniInfo)
        radky.add("")
        radky.add(ShizukuRecorder.detail())
        stav.text = radky.joinToString("\n")

        seznam.removeAllViews()
        val items = RecordStore.list(this)
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = "Zatím žádné nahrávky."
            t.setPadding(0, 24, 0, 0)
            seznam.addView(t)
            return
        }
        items.forEach { item -> seznam.addView(radek(item)) }
    }

    private fun radek(item: RecordStore.Item): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, 24, 0, 24)

        val file = File(item.file)
        val nadpis = TextView(this)
        val datum = DateFormat.format("d.M.yyyy H:mm", Date(item.startedAt))
        val velikost = Formatter.formatShortFileSize(this, file.length())
        val cislo = if (item.number.isBlank()) "" else " · ${item.number}"
        nadpis.text = buildString {
            if (item.keep) append("★ ")
            if (item.name.isNotBlank()) append(item.name).append(" · ")
            append(datum)
            append(cislo)
            append(" · ")
            append(velikost)
        }
        nadpis.textSize = 16f
        box.addView(nadpis)

        val poznamka = TextView(this)
        poznamka.text = item.note
        poznamka.textSize = 12f
        poznamka.alpha = 0.7f
        box.addView(poznamka)

        val tlacitka = LinearLayout(this)
        tlacitka.orientation = LinearLayout.HORIZONTAL
        tlacitka.gravity = Gravity.START

        tlacitka.addView(maleTlacitko("Přehrát") { prehrat(file) })
        tlacitka.addView(maleTlacitko("Název") { pojmenovat(item) })
        tlacitka.addView(maleTlacitko(if (item.keep) "Uvolnit" else "Ponechat") {
            RecordStore.setKeep(this, item.file, !item.keep)
            obnovit()
        })
        tlacitka.addView(maleTlacitko("Sdílet") { sdilet(file) })
        tlacitka.addView(maleTlacitko("Smazat") {
            AlertDialog.Builder(this)
                .setMessage("Smazat tuto nahrávku?")
                .setPositiveButton("Smazat") { _, _ ->
                    RecordStore.delete(this, item.file)
                    obnovit()
                }
                .setNegativeButton("Zpět", null)
                .show()
        })
        box.addView(tlacitka)
        return box
    }

    private fun pojmenovat(item: RecordStore.Item) {
        val vstup = EditText(this)
        vstup.setText(item.name)
        vstup.hint = "např. servis kotle, Novák – reklamace"
        vstup.setSingleLine()
        val ramecek = LinearLayout(this)
        ramecek.orientation = LinearLayout.VERTICAL
        ramecek.setPadding(48, 24, 48, 0)
        ramecek.addView(vstup)
        AlertDialog.Builder(this)
            .setTitle("Název nahrávky")
            .setView(ramecek)
            .setPositiveButton("Uložit") { _, _ ->
                RecordStore.setName(this, item.file, vstup.text.toString())
                obnovit()
            }
            .setNeutralButton("Smazat název") { _, _ ->
                RecordStore.setName(this, item.file, "")
                obnovit()
            }
            .setNegativeButton("Zpět", null)
            .show()
    }

    private fun maleTlacitko(text: String, akce: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 12f
        b.setPadding(8, 0, 8, 0)
        b.setOnClickListener { akce() }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginEnd = 8
        b.layoutParams = lp
        return b
    }

    private fun uri(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.files", file)

    private fun prehrat(file: File) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri(file), if (file.extension == "wav") "audio/x-wav" else "audio/mp4")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (t: Throwable) {
            Toast.makeText(this, "Nemám čím přehrát: $t", Toast.LENGTH_LONG).show()
        }
    }

    private fun sdilet(file: File) {
        try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = if (file.extension == "wav") "audio/x-wav" else "audio/mp4"
            i.putExtra(Intent.EXTRA_STREAM, uri(file))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Sdílet nahrávku"))
        } catch (t: Throwable) {
            Toast.makeText(this, "Sdílení selhalo: $t", Toast.LENGTH_LONG).show()
        }
    }
}

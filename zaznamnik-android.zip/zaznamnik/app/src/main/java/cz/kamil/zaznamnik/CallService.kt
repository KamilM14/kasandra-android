package cz.kamil.zaznamnik

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import java.io.File

/**
 * Trvale běžící služba, která hlídá stav hovoru a spouští nahrávání.
 */
class CallService : Service() {

    companion object {
        private const val TAG = "Zaznamnik"
        const val CHANNEL = "zaznamnik"
        const val CHANNEL_VYSTRAHA = "zaznamnik_vystrahy"
        const val NOTIF_ID = 1
        const val NOTIF_VYSTRAHA = 2
        private const val KONTROLA_MS = 5 * 60 * 1000L
        const val EXTRA_NUMBER = "cislo"

        @Volatile var posledniInfo: String = "zatím nic"
        @Volatile var nahrava: Boolean = false

        fun zajistitBeh(ctx: Context, number: String? = null) {
            val i = Intent(ctx, CallService::class.java)
            if (number != null) i.putExtra(EXTRA_NUMBER, number)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
                else ctx.startService(i)
            } catch (t: Throwable) {
                Log.w(TAG, "službu nešlo spustit: $t")
            }
        }
    }

    private val hlavni = Handler(Looper.getMainLooper())
    private var telephony: TelephonyManager? = null
    private var callback: Any? = null
    private var currentFile: File? = null
    private var micRecorder: MediaRecorder? = null
    private enum class Rezim { NIC, ADB, SHIZUKU, MIK }
    private var rezim = Rezim.NIC
    private var adbThread: Thread? = null
    private var adbStream: io.github.muntashirakon.adb.AdbStream? = null
    @Volatile private var adbBezi = false
    @Volatile private var adbRate = 0
    @Volatile private var adbBytes = 0L
    private var cisloHovoru = ""
    private var startTime = 0L
    private var shizukuBylOk = true

    private val kontrolaShizuku = object : Runnable {
        override fun run() {
            zkontrolovatShizuku()
            hlavni.postDelayed(this, KONTROLA_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        vytvoritKanal()
        try {
            startForeground(NOTIF_ID, notifikace("Hlídám hovory"))
        } catch (t: Throwable) {
            // Bez uděleného oprávnění k mikrofonu systém službu v popředí nepustí.
            Log.w(TAG, "startForeground selhalo: $t")
            posledniInfo = "Chybí oprávnění – otevři aplikaci a povol mikrofon i telefon"
            stopSelf()
            return
        }
        sledovatStavHovoru()
        hlavni.postDelayed(kontrolaShizuku, 10_000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getStringExtra(EXTRA_NUMBER)?.let { if (it.isNotBlank()) cisloHovoru = it }
        // Kdyby se sledování hovorů dřív nepovedlo (třeba chybělo oprávnění), zkusit znovu.
        if (callback == null) sledovatStavHovoru()
        return START_STICKY
    }

    override fun onDestroy() {
        hlavni.removeCallbacks(kontrolaShizuku)
        ukoncitNahravani()
        try {
            val tm = telephony
            val cb = callback
            if (tm != null && cb != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && cb is TelephonyCallback) {
                    tm.unregisterTelephonyCallback(cb)
                } else if (cb is PhoneStateListener) {
                    @Suppress("DEPRECATION")
                    tm.listen(cb, PhoneStateListener.LISTEN_NONE)
                }
            }
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun sledovatStavHovoru() {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return
        telephony = tm
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) = zmenaStavu(state)
                }
                callback = cb
                tm.registerTelephonyCallback(mainExecutor, cb)
            } else {
                @Suppress("DEPRECATION")
                val cb = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        if (!phoneNumber.isNullOrBlank()) cisloHovoru = phoneNumber
                        zmenaStavu(state)
                    }
                }
                callback = cb
                @Suppress("DEPRECATION")
                tm.listen(cb, PhoneStateListener.LISTEN_CALL_STATE)
            }
            if (posledniInfo.startsWith("Chybí")) posledniInfo = "připraveno"
        } catch (t: Throwable) {
            Log.w(TAG, "stav hovoru nejde sledovat: $t")
            posledniInfo = "Chybí oprávnění ke stavu hovoru"
        }
    }

    /** Hlídá, jestli Shizuku pořád běží – bez něj se nahraje jen mikrofon. */
    private fun zkontrolovatShizuku() {
        if (nahrava) return
        val ok = try {
            ShizukuRecorder.shizukuAvailable() && ShizukuRecorder.hasPermission()
        } catch (t: Throwable) {
            false
        }
        if (!ok && shizukuBylOk) {
            vystraha(
                "Shizuku neběží",
                "Hovory se teď nahrají jen z mikrofonu. Klepni pro návod, jak Shizuku znovu spustit."
            )
        } else if (ok && !shizukuBylOk) {
            zrusitVystrahu()
        }
        shizukuBylOk = ok
        aktualizovatNotifikaci(if (ok) "Hlídám hovory" else "Hlídám hovory – Shizuku neběží")
    }

    private fun zmenaStavu(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> if (!nahrava) spustitNahravani()
            TelephonyManager.CALL_STATE_IDLE -> if (nahrava) ukoncitNahravani()
        }
    }

    private fun spustitNahravani() {
        nahrava = true
        startTime = System.currentTimeMillis()
        aktualizovatNotifikaci("Nahrávám hovor…")
        // 1) vlastní ADB (bez Shizuku), 2) Shizuku, 3) mikrofon
        if (AdbRecorder.jePripojeno() || AdbRecorder.bylSparovan(this)) {
            val file = RecordStore.newFile(this, "wav")
            currentFile = file
            rezim = Rezim.ADB
            spustitAdbNahravani(file)
        } else {
            spustitShizuku()
        }
    }

    private fun spustitAdbNahravani(file: File) {
        adbBezi = true
        adbBytes = 0
        adbRate = 0
        adbThread = Thread {
            val stream = if (AdbRecorder.zajistitSpojeni(this)) AdbRecorder.otevritNahravani(this) else null
            if (stream == null) {
                hlavni.post { adbSelhalo("ADB nepřipojeno / proud se neotevřel") }
                return@Thread
            }
            adbStream = stream
            var out: java.io.FileOutputStream? = null
            try {
                val input = stream.openInputStream()
                // přečíst hlavičku "ZAZN1 <zdroj> <rate>"
                val sb = StringBuilder()
                var c = input.read()
                while (c != -1 && c != '\n'.code && sb.length < 64) { sb.append(c.toChar()); c = input.read() }
                val casti = sb.toString().trim().split(" ")
                if (casti.size < 3 || casti[0] != "ZAZN1" || casti[1] == "NONE") {
                    hlavni.post { adbSelhalo("ADB zdroj se neotevřel (${sb})") }
                    return@Thread
                }
                val zdroj = casti[1]
                val rate = casti[2].toIntOrNull() ?: 16000
                adbRate = rate
                posledniInfo = "ADB: $zdroj @ ${rate}Hz"
                hlavni.post { aktualizovatNotifikaci("Nahrávám hovor (ADB)") }
                out = java.io.FileOutputStream(file)
                out.write(Wav.hlavicka(rate, 0))
                val buf = ByteArray(8192)
                while (adbBezi) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n > 0) { out.write(buf, 0, n); adbBytes += n }
                }
            } catch (t: Throwable) {
                Log.w(TAG, "adb nahrávání", t)
            } finally {
                try { out?.flush(); out?.close() } catch (_: Throwable) {}
                try { stream.close() } catch (_: Throwable) {}
            }
        }.also { it.start() }
    }

    /** Volá se z hlavního vlákna, když ADB cesta selže – zkusí Shizuku. */
    private fun adbSelhalo(duvod: String) {
        Log.w(TAG, "ADB cesta selhala: $duvod")
        adbBezi = false
        currentFile?.delete()
        currentFile = null
        if (!nahrava) return
        // spadnout na Shizuku (a ta případně na mikrofon)
        spustitShizuku()
    }

    private fun spustitShizuku() {
        val file = RecordStore.newFile(this, "wav")
        currentFile = file
        rezim = Rezim.SHIZUKU
        ShizukuRecorder.start(file) { vysledek ->
            if (vysledek.startsWith("CHYBA")) {
                Log.w(TAG, "Shizuku nahrávání selhalo: $vysledek")
                file.delete()
                spustitZalozniMikrofon(vysledek)
            } else {
                posledniInfo = "Shizuku: $vysledek"
                aktualizovatNotifikaci("Nahrávám hovor (Shizuku)")
            }
        }
    }

    /** Když ADB i Shizuku nefungují, nahrává se aspoň mikrofonem (nutný hlasitý odposlech). */
    private fun spustitZalozniMikrofon(duvod: String) {
        try {
            val file = RecordStore.newFile(this, "m4a")
            currentFile = file
            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            micRecorder = rec
            rezim = Rezim.MIK
            posledniInfo = "Záložní mikrofon ($duvod)"
            aktualizovatNotifikaci("Nahrávám mikrofonem")
            shizukuBylOk = false
            vystraha(
                "Nahrávám jen mikrofonem",
                "Plné nahrávání není k dispozici, druhá strana bude slyšet jen při hlasitém odposlechu. Klepni pro návod."
            )
        } catch (t: Throwable) {
            Log.e(TAG, "ani mikrofon nejde", t)
            posledniInfo = "Nahrávání selhalo: $t"
            nahrava = false
            rezim = Rezim.NIC
            currentFile?.delete()
            currentFile = null
            aktualizovatNotifikaci("Hlídám hovory")
        }
    }

    private fun ukoncitNahravani() {
        if (!nahrava) return
        nahrava = false
        val file = currentFile
        currentFile = null
        val aktualniRezim = rezim
        rezim = Rezim.NIC
        // ADB cesta se ukončuje mimo hlavní vlákno (uzavření síťového proudu).
        if (aktualniRezim == Rezim.ADB) {
            val cislo = cisloHovoru
            cisloHovoru = ""
            val stream = adbStream
            val thread = adbThread
            adbStream = null
            adbThread = null
            adbBezi = false
            val app = applicationContext
            Thread {
                try { stream?.close() } catch (_: Throwable) {}
                try { thread?.join(3000) } catch (_: Throwable) {}
                if (file != null && adbRate > 0 && adbBytes > 0) {
                    try { Wav.dokoncit(file.absolutePath, adbRate, adbBytes) } catch (t: Throwable) { Log.w(TAG, "wav", t) }
                }
                if (file != null) {
                    if (file.exists() && file.length() > 1024) RecordStore.add(app, file, cislo, posledniInfo)
                    else file.delete()
                }
            }.start()
            aktualizovatNotifikaci("Hlídám hovory")
            return
        }

        var popis: String
        when (aktualniRezim) {
            Rezim.ADB -> { popis = posledniInfo }
            Rezim.MIK -> {
                popis = "mikrofon"
                try { micRecorder?.stop() } catch (t: Throwable) { Log.w(TAG, "stop mikrofonu: $t") }
                try { micRecorder?.release() } catch (_: Throwable) {}
                micRecorder = null
            }
            Rezim.SHIZUKU -> {
                popis = ShizukuRecorder.stop()
                ShizukuRecorder.unbind()
            }
            Rezim.NIC -> popis = posledniInfo
        }
        posledniInfo = popis
        if (file != null) {
            if (file.exists() && file.length() > 1024) {
                RecordStore.add(this, file, cisloHovoru, popis)
            } else {
                file.delete()
            }
        }
        cisloHovoru = ""
        aktualizovatNotifikaci("Hlídám hovory")
    }

    private fun vytvoritKanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                val ch = NotificationChannel(CHANNEL, "Záznamník hovorů", NotificationManager.IMPORTANCE_LOW)
                ch.setShowBadge(false)
                nm.createNotificationChannel(ch)
            }
            if (nm.getNotificationChannel(CHANNEL_VYSTRAHA) == null) {
                val ch = NotificationChannel(
                    CHANNEL_VYSTRAHA, "Výstrahy", NotificationManager.IMPORTANCE_DEFAULT
                )
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun notifikace(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("Záznamník")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun vystraha(nadpis: String, text: String) {
        hlavni.post {
            try {
                val pi = PendingIntent.getActivity(
                    this, 1, Intent(this, HelpActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    Notification.Builder(this, CHANNEL_VYSTRAHA)
                else @Suppress("DEPRECATION") Notification.Builder(this)
                val n = b.setContentTitle(nadpis)
                    .setContentText(text)
                    .setStyle(Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.stat_sys_warning)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
                getSystemService(NotificationManager::class.java).notify(NOTIF_VYSTRAHA, n)
            } catch (_: Throwable) {}
        }
    }

    private fun zrusitVystrahu() {
        hlavni.post {
            try { getSystemService(NotificationManager::class.java).cancel(NOTIF_VYSTRAHA) } catch (_: Throwable) {}
        }
    }

    private fun aktualizovatNotifikaci(text: String) {
        hlavni.post {
            try {
                val nm = getSystemService(NotificationManager::class.java)
                nm.notify(NOTIF_ID, notifikace(text))
            } catch (_: Throwable) {}
        }
    }
}

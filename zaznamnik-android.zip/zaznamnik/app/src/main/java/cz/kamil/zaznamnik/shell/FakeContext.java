package cz.kamil.zaznamnik.shell;

import android.content.AttributionSource;
import android.content.Context;
import android.content.ContextWrapper;

/**
 * Kontext, který se tváří jako balíček "com.android.shell" (uid 2000).
 * Bez něj systém odmítne nahrávání ze zdroje VOICE_CALL, protože proces
 * Shizuku user service žádný skutečný balíček nemá.
 * Postup převzat z projektu scrcpy (Apache 2.0).
 */
public final class FakeContext extends ContextWrapper {

    public static final String PACKAGE_NAME = "com.android.shell";
    public static final int SHELL_UID = 2000;

    private static FakeContext instance;

    public static synchronized FakeContext get() {
        if (instance == null) {
            instance = new FakeContext(Workarounds.getSystemContext());
        }
        return instance;
    }

    private FakeContext(Context base) {
        super(base);
    }

    @Override
    public String getPackageName() {
        return PACKAGE_NAME;
    }

    // V veřejném SDK skrytá metoda – bez @Override, aby to šlo přeložit.
    public String getOpPackageName() {
        return PACKAGE_NAME;
    }

    public AttributionSource getAttributionSource() {
        AttributionSource.Builder builder = new AttributionSource.Builder(SHELL_UID);
        builder.setPackageName(PACKAGE_NAME);
        return builder.build();
    }

    public int getDeviceId() {
        return 0;
    }

    @Override
    public Context getApplicationContext() {
        return this;
    }
}

package cz.kamil.zaznamnik

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import cz.kamil.zaznamnik.shell.RecorderService
import rikka.shizuku.Shizuku
import java.io.File

/** Spojení s procesem, který pod uživatelem shell umí sáhnout na zvuk hovoru. */
object ShizukuRecorder {

    private const val TAG = "Zaznamnik"
    private const val BALICEK = "cz.kamil.zaznamnik"
    private const val VERZE = 8
    const val PERMISSION_CODE = 4711

    @Volatile private var service: IRecorder? = null
    @Volatile private var binding = false
    private val waiting = mutableListOf<(IRecorder?) -> Unit>()

    private val args: Shizuku.UserServiceArgs
        get() = Shizuku.UserServiceArgs(
            ComponentName(BALICEK, RecorderService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("nahravani")
            .debuggable(false)
            .version(VERZE)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IRecorder.Stub.asInterface(binder) else null
            binding = false
            val copy = synchronized(waiting) { waiting.toList().also { waiting.clear() } }
            copy.forEach { it(service) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    fun shizukuAvailable(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    fun stav(): String = when {
        !shizukuAvailable() -> "Shizuku neběží / apka k němu nedosáhne"
        !hasPermission() -> "Shizuku běží, chybí povolení"
        service != null -> "připraveno"
        else -> "Shizuku připraveno (služba se spustí při hovoru)"
    }

    /** Podrobný rozbor spojení – pro ladění. */
    fun detail(): String {
        val sb = StringBuilder()
        val ping = try { Shizuku.pingBinder() } catch (t: Throwable) { false }
        sb.append("spojení (binder): ").append(if (ping) "ano" else "NE").append('\n')
        sb.append("verze Shizuku: ").append(try { Shizuku.getVersion().toString() } catch (t: Throwable) { "neznámá (${t.javaClass.simpleName})" }).append('\n')
        sb.append("uid procesu Shizuku: ").append(try { Shizuku.getUid().toString() } catch (t: Throwable) { "neznámé" }).append('\n')
        sb.append("stará verze (pre-v11): ").append(try { Shizuku.isPreV11().toString() } catch (t: Throwable) { "?" }).append('\n')
        sb.append("povolení: ").append(
            try {
                when (Shizuku.checkSelfPermission()) {
                    PackageManager.PERMISSION_GRANTED -> "uděleno"
                    else -> "neuděleno"
                }
            } catch (t: Throwable) { "nelze zjistit (${t.javaClass.simpleName}: ${t.message})" }
        ).append('\n')
        sb.append("pomocná služba: ").append(if (service != null) "spojena" else "nespojena")
        return sb.toString()
    }

    /** Zajistí spojení; callback dostane null, když to nejde. */
    fun connect(callback: (IRecorder?) -> Unit) {
        val existing = service
        if (existing != null && existing.asBinder().pingBinder()) {
            callback(existing)
            return
        }
        if (!shizukuAvailable() || !hasPermission()) {
            callback(null)
            return
        }
        synchronized(waiting) { waiting.add(callback) }
        if (binding) return
        binding = true
        try {
            Shizuku.bindUserService(args, connection)
        } catch (t: Throwable) {
            Log.e(TAG, "bindUserService selhalo", t)
            binding = false
            val copy = synchronized(waiting) { waiting.toList().also { waiting.clear() } }
            copy.forEach { it(null) }
        }
    }

    fun start(file: File, callback: (String) -> Unit) {
        connect { svc ->
            if (svc == null) {
                callback("CHYBA: Shizuku není dostupné")
                return@connect
            }
            try {
                val pfd = ParcelFileDescriptor.open(
                    file,
                    ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
                )
                val result = pfd.use { svc.start(it) }
                callback(result)
            } catch (t: Throwable) {
                callback("CHYBA: $t")
            }
        }
    }

    fun stop(): String = try {
        service?.stop() ?: "služba neběží"
    } catch (t: Throwable) {
        "CHYBA při ukončení: $t"
    }

    fun isRecording(): Boolean = try { service?.isRecording ?: false } catch (t: Throwable) { false }

    fun probe(callback: (String) -> Unit) {
        connect { svc ->
            if (svc == null) {
                callback("Nepodařilo se spustit pomocnou službu.\n\n" + detail())
                return@connect
            }
            callback(try { svc.probe() } catch (t: Throwable) { "CHYBA: $t" })
        }
    }

    fun unbind() {
        try { Shizuku.unbindUserService(args, connection, true) } catch (_: Throwable) {}
        service = null
    }

    @Suppress("unused")
    fun requestPermission(ctx: Context) {
        try { Shizuku.requestPermission(PERMISSION_CODE) } catch (_: Throwable) {}
    }
}

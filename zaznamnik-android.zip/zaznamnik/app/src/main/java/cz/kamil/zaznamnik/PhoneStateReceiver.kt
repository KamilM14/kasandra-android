package cz.kamil.zaznamnik

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/** Probudí službu, kdyby ji systém zabil. */
class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val cislo = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        CallService.zajistitBeh(context, cislo)
    }
}

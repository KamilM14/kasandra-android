package cz.kamil.zaznamnik

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import android.sun.security.x509.AlgorithmId
import android.sun.security.x509.CertificateAlgorithmId
import android.sun.security.x509.CertificateExtensions
import android.sun.security.x509.CertificateIssuerName
import android.sun.security.x509.CertificateSerialNumber
import android.sun.security.x509.CertificateSubjectName
import android.sun.security.x509.CertificateValidity
import android.sun.security.x509.CertificateVersion
import android.sun.security.x509.CertificateX509Key
import android.sun.security.x509.KeyIdentifier
import android.sun.security.x509.PrivateKeyUsageExtension
import android.sun.security.x509.SubjectKeyIdentifierExtension
import android.sun.security.x509.X500Name
import android.sun.security.x509.X509CertImpl
import android.sun.security.x509.X509CertInfo
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random

/**
 * Vlastní ADB spojení aplikace. Klíč i certifikát se vygenerují jednou
 * a uloží, aby po spárování s bezdrátovým laděním stačilo příště jen připojit.
 */
class AdbManager private constructor(ctx: Context) : AbsAdbConnectionManager() {

    private val privateKey: PrivateKey
    private val certificate: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val dir = File(ctx.filesDir, "adb").apply { mkdirs() }
        val keyFile = File(dir, "key.pk8")
        val certFile = File(dir, "cert.der")

        if (keyFile.exists() && certFile.exists()) {
            val kf = KeyFactory.getInstance("RSA")
            privateKey = kf.generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
            certificate = CertificateFactory.getInstance("X.509")
                .generateCertificate(certFile.inputStream())
        } else {
            val generator = KeyPairGenerator.getInstance("RSA")
            generator.initialize(2048, SecureRandom.getInstance("SHA1PRNG"))
            val pair = generator.generateKeyPair()
            privateKey = pair.private
            certificate = vytvoritCertifikat(pair.public, privateKey)
            keyFile.writeBytes(PKCS8EncodedKeySpec(privateKey.encoded).encoded)
            certFile.writeBytes(certificate.encoded)
        }
    }

    override fun getPrivateKey(): PrivateKey = privateKey
    override fun getCertificate(): Certificate = certificate
    override fun getDeviceName(): String = "Zaznamnik"

    private fun vytvoritCertifikat(publicKey: PublicKey, privKey: PrivateKey): Certificate {
        val algorithmName = "SHA512withRSA"
        val expiry = System.currentTimeMillis() + 10L * 365 * 24 * 60 * 60 * 1000
        val extensions = CertificateExtensions()
        extensions.set(
            "SubjectKeyIdentifier",
            SubjectKeyIdentifierExtension(KeyIdentifier(publicKey).identifier)
        )
        val x500Name = X500Name("CN=Zaznamnik")
        val notBefore = Date()
        val notAfter = Date(expiry)
        extensions.set("PrivateKeyUsage", PrivateKeyUsageExtension(notBefore, notAfter))
        val validity = CertificateValidity(notBefore, notAfter)
        val info = X509CertInfo()
        info.set("version", CertificateVersion(2))
        info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
        info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(algorithmName)))
        info.set("subject", CertificateSubjectName(x500Name))
        info.set("key", CertificateX509Key(publicKey))
        info.set("validity", validity)
        info.set("issuer", CertificateIssuerName(x500Name))
        info.set("extensions", extensions)
        val cert = X509CertImpl(info)
        cert.sign(privKey, algorithmName)
        return cert
    }

    companion object {
        @Volatile private var INSTANCE: AdbManager? = null

        fun get(ctx: Context): AdbManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AdbManager(ctx.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
